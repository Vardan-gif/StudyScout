'use strict';

/**
 * app.js — StudyScout Frontend  (Three-Page Edition)
 *
 * Navigation:
 *   #          →  Home    (form + example chips)
 *   #research  →  Research page (SVG progress ring + live stats)
 *   #results   →  Results workspace (tabs: Overview / Resources / Map / Plan)
 *
 * Architecture:
 *   • Hash-based routing — no server changes needed, refresh-safe
 *   • State machine: navigateTo(PAGE.HOME | .RESEARCH | .RESULTS)
 *   • Progress ring driven by pipeline-stage timers (honest — same delays as real pipeline)
 *   • All rendering functions unchanged from previous version
 *
 * IMPORTANT: every factual value rendered (titles, URLs, scores, counts,
 * reasons, plan slots) comes from the /api/research or /api/upload-syllabus
 * JSON response. Nothing hardcodes resource data.
 */

// ── Icon set (inline SVG, no emoji) ──────────────────────────────────────────
const ICONS = {
  video:    '<svg viewBox="0 0 24 24" fill="none"><rect x="2.5" y="5.5" width="14" height="13" rx="2.5" stroke="currentColor" stroke-width="1.7"/><path d="M16.5 10.2l5-3v9.6l-5-3" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
  course:   '<svg viewBox="0 0 24 24" fill="none"><path d="M4 5.5A2.5 2.5 0 016.5 3H19a1 1 0 011 1v14.5a1 1 0 01-1 1H6.5A2.5 2.5 0 014 17V5.5z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M4 17a2.5 2.5 0 012.5-2.5H20" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
  article:  '<svg viewBox="0 0 24 24" fill="none"><path d="M6 3.5h9l4 4V19a1.2 1.2 0 01-1.2 1.2H6A1.2 1.2 0 014.8 19V4.7A1.2 1.2 0 016 3.5z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/><path d="M9 12h6M9 15.5h6" stroke="currentColor" stroke-width="1.5" stroke-linecap="round"/></svg>',
  reference:'<svg viewBox="0 0 24 24" fill="none"><path d="M6 3.5h11a1 1 0 011 1V21l-6.5-3.5L5 21V4.5a1 1 0 011-1z" stroke="currentColor" stroke-width="1.7" stroke-linejoin="round"/></svg>',
  clock:    '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8.2" stroke="currentColor" stroke-width="1.6"/><path d="M12 8v4.3l3 2" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  search:   '<svg viewBox="0 0 24 24" fill="none"><circle cx="10.5" cy="10.5" r="6.5" stroke="currentColor" stroke-width="1.7"/><path d="M19.5 19.5L15 15" stroke="currentColor" stroke-width="1.7" stroke-linecap="round"/></svg>',
  stack:    '<svg viewBox="0 0 24 24" fill="none"><path d="M12 3l9 5-9 5-9-5 9-5z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/><path d="M3 13l9 5 9-5" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
  target:   '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="4.3" stroke="currentColor" stroke-width="1.6"/><circle cx="12" cy="12" r="1.1" fill="currentColor"/></svg>',
  bolt:     '<svg viewBox="0 0 24 24" fill="none"><path d="M13 2.5L4.5 14H11l-1 7.5L19.5 10H13l0-7.5z" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/></svg>',
  globe:    '<svg viewBox="0 0 24 24" fill="none"><circle cx="12" cy="12" r="8.5" stroke="currentColor" stroke-width="1.6"/><path d="M3.5 12h17M12 3.5c2.4 2.3 3.7 5.3 3.7 8.5s-1.3 6.2-3.7 8.5c-2.4-2.3-3.7-5.3-3.7-8.5S9.6 5.8 12 3.5z" stroke="currentColor" stroke-width="1.6"/></svg>',
};

function typeIcon(type) {
  return ICONS[type] ?? ICONS.article;
}

// ── Utility helpers ────────────────────────────────────────────────────────────
function esc(str) {
  return String(str ?? '')
    .replace(/&/g,  '&amp;')
    .replace(/</g,  '&lt;')
    .replace(/>/g,  '&gt;')
    .replace(/"/g,  '&quot;')
    .replace(/'/g,  '&#39;');
}

function safeURL(str) {
  const s = String(str ?? '');
  return /^https?:\/\//i.test(s) ? s.replace(/"/g, '%22') : '#';
}

function pad(n) { return String(n).padStart(2, '0'); }

// ── Element refs ───────────────────────────────────────────────────────────────
const topicInput        = document.getElementById('topic');
const levelGroup        = document.getElementById('level-group');
const goalGroup         = document.getElementById('goal-group');
const timeGroup         = document.getElementById('time-group');
const customTimeGroup   = document.getElementById('custom-time-group');
const customMinutes     = document.getElementById('customMinutes');
const syllabusFile      = document.getElementById('syllabus-file');
const uploadZone        = document.getElementById('upload-zone');
const researchBtn       = document.getElementById('research-btn');
const demoBtn           = document.getElementById('demo-btn');

// Document analysis UI elements
const docAnalysisProgress = document.getElementById('doc-analysis-progress');
const docAnalysisFilename = document.getElementById('doc-analysis-filename');
const docClassificationCard = document.getElementById('doc-classification-card');
const docClassBadge       = document.getElementById('doc-class-badge');
const docClassSubject     = document.getElementById('doc-class-subject');
const docClassReason      = document.getElementById('doc-class-reason');
const docClassStats       = document.getElementById('doc-class-stats');
const docClassClose       = document.getElementById('doc-class-close');
const docResearchBtn      = document.getElementById('doc-research-btn');
const docTopicPreview     = document.getElementById('doc-topic-preview');
const docTopicTree        = document.getElementById('doc-topic-tree');
const docComposedWrap     = document.getElementById('doc-composed-topic-wrap');
const docComposedTopic    = document.getElementById('doc-composed-topic');
const confidenceBarFill   = document.getElementById('confidence-bar-fill');
const confidenceLabel     = document.getElementById('confidence-label');
const docLowconfCard      = document.getElementById('doc-lowconf-card');
const docLowconfType      = document.getElementById('doc-lowconf-type');
const docLowconfReason    = document.getElementById('doc-lowconf-reason');
const docLowconfUse       = document.getElementById('doc-lowconf-use');
const docLowconfRetry     = document.getElementById('doc-lowconf-retry');
const docInvalidPanel     = document.getElementById('doc-invalid-panel');
const docInvalidReason    = document.getElementById('doc-invalid-reason');
const docInvalidRetry     = document.getElementById('doc-invalid-retry');

// Home error card
const homeErrorCard     = document.getElementById('home-error-card');
const errorMessage      = document.getElementById('error-message');
const errorRetryBtn     = document.getElementById('error-retry-btn');
const errorDetailToggle = document.getElementById('error-detail-toggle');
const errorDetailBody   = document.getElementById('error-detail-body');

// Results page
const goalBarEl         = document.getElementById('goal-bar');
const resourcesCountEl  = document.getElementById('resources-count');
const resourceGrid      = document.getElementById('resource-grid');
const studyPlanWrap     = document.getElementById('study-plan-wrap');
const tabButtons        = document.querySelectorAll('.tab-btn');
const tabContents       = document.querySelectorAll('.tab-content');
const filterBtns        = document.querySelectorAll('.filter-btn');
const sortSelect        = document.getElementById('sort-select');
const compareBar        = document.getElementById('compare-bar');
const compareCountEl    = document.getElementById('compare-count');
const compareBtn        = document.getElementById('compare-btn');
const compareClearBtn   = document.getElementById('compare-clear-btn');
const comparisonWrap    = document.getElementById('comparison-table-wrap');
const comparisonTable   = document.getElementById('comparison-table');
const comparisonClose   = document.getElementById('comparison-close');
const alternativeResult = document.getElementById('alternative-result');
const alternativeBack   = document.getElementById('alternative-back');
const alternativeGrid   = document.getElementById('alternative-grid');
const conceptMapEl      = document.getElementById('concept-map');
const statsGridEl       = document.getElementById('stats-grid');
const topResourceEl     = document.getElementById('top-resource-preview');
const startOverBtn      = document.getElementById('start-over-btn');
const syllabusPanel     = document.getElementById('syllabus-panel');
const syllabusFilename  = document.getElementById('syllabus-filename');
const syllabusTopicsEl  = document.getElementById('syllabus-topics');
const syllabusClose     = document.getElementById('syllabus-close');
const syllabusResearchBtn = document.getElementById('syllabus-research-btn');

// Research page
const ringFill          = document.getElementById('ring-fill');
const ringPct           = document.getElementById('ring-pct');
const ringState         = document.getElementById('ring-state');
const statTimeEl        = document.getElementById('stat-time');
const statFoundEl       = document.getElementById('stat-found');
const statBestEl        = document.getElementById('stat-best');
const typeBreakdownEl   = document.getElementById('type-breakdown');
const researchCompleteCard = document.getElementById('research-complete-card');
const researchStopReason   = document.getElementById('research-stop-reason');
const btnViewResults    = document.getElementById('btn-view-results');
const btnCancelResearch = document.getElementById('btn-cancel-research');
const agentQueriesEl    = document.getElementById('agent-queries');
const agentQueriesListEl = document.getElementById('agent-queries-list');
const researchTopicText = document.getElementById('research-topic-text');
const researchGoalPills = document.getElementById('research-goal-pills');
const agentCurrentAction = document.getElementById('agent-current-action');

// Header slots
const headerHome        = document.getElementById('header-home');
const headerResearch    = document.getElementById('header-research');
const headerResults     = document.getElementById('header-results');
const headerResearchTopic = document.getElementById('header-research-topic');
const headerResultsMeta = document.getElementById('header-results-meta');

// ── Application state ──────────────────────────────────────────────────────────
const PAGE = { HOME: 'home', RESEARCH: 'research', RESULTS: 'results' };
let currentPage     = PAGE.HOME;
let currentResults  = null;   // Last successful API response
let pendingBody     = null;   // Body passed to doResearch, kept until results render
let selectedForCompare = new Set();
let stepTimers      = [];
let elapsedTimer    = null;
let researchStartTime = null;
let abortController = null;
let currentFilter   = 'all';
let currentSort     = 'match';

// ── Page navigation (hash-based) ───────────────────────────────────────────────
const RING_CIRCUMFERENCE = 326.7;  // 2π × 52

function navigateTo(page) {
  currentPage = page;
  const hash = page === PAGE.HOME ? '' : page;
  // Avoid pushing duplicate history entries
  if (location.hash.slice(1) !== hash) {
    location.hash = hash;
  } else {
    applyPageView();
  }
}

function applyPageView() {
  // Show/hide page sections
  document.querySelectorAll('.page').forEach(p => {
    p.classList.toggle('hidden', p.id !== 'page-' + currentPage);
  });

  // Show/hide header slots
  headerHome.classList.toggle('hidden',     currentPage !== PAGE.HOME);
  headerResearch.classList.toggle('hidden', currentPage !== PAGE.RESEARCH);
  headerResults.classList.toggle('hidden',  currentPage !== PAGE.RESULTS);
}

window.addEventListener('hashchange', () => {
  const h = location.hash.slice(1);
  // Guard: don't navigate to research/results if there's nothing to show
  if (h === PAGE.RESEARCH && !pendingBody && !currentResults) {
    location.hash = ''; return;
  }
  if (h === PAGE.RESULTS && !currentResults) {
    location.hash = ''; return;
  }
  if (h === PAGE.HOME || h === PAGE.RESEARCH || h === PAGE.RESULTS) {
    currentPage = h;
    applyPageView();
  } else {
    currentPage = PAGE.HOME;
    applyPageView();
  }
});

// Initial page load
(function init() {
  const h = location.hash.slice(1);
  if ((h === PAGE.RESULTS && currentResults) || (h === PAGE.RESEARCH && pendingBody)) {
    currentPage = h;
  } else {
    currentPage = PAGE.HOME;
    if (h) location.hash = '';
  }
  applyPageView();
})();

// ── Progress ring ──────────────────────────────────────────────────────────────
function updateRing(pct) {
  if (!ringFill) return;
  const offset = RING_CIRCUMFERENCE * (1 - pct / 100);
  ringFill.style.strokeDashoffset = offset;
  if (ringPct) ringPct.textContent = Math.round(pct) + '%';
  if (ringState) {
    if (pct >= 100) {
      ringState.textContent = 'Complete';
      ringFill.classList.add('ring-complete');
    } else if (pct >= 80) {
      ringState.textContent = 'Ranking';
    } else if (pct >= 62) {
      ringState.textContent = 'Analyzing';
    } else if (pct >= 40) {
      ringState.textContent = 'Fetching';
    } else if (pct >= 14) {
      ringState.textContent = 'Planning';
    } else {
      ringState.textContent = 'Starting';
    }
  }
}

// ── Elapsed timer ──────────────────────────────────────────────────────────────
function startElapsedTimer() {
  researchStartTime = Date.now();
  if (!statTimeEl) return;
  statTimeEl.textContent = '0s';
  elapsedTimer = setInterval(() => {
    const secs = ((Date.now() - researchStartTime) / 1000).toFixed(1);
    if (statTimeEl) statTimeEl.textContent = secs + 's';
  }, 200);
}

function stopElapsedTimer() {
  if (elapsedTimer) { clearInterval(elapsedTimer); elapsedTimer = null; }
}

// ── Demo / example presets ─────────────────────────────────────────────────────
const DEMO = {
  topic: "Teach me Kirchhoff's Laws for my first-year engineering exam. I have 60 minutes. I'm a beginner and want beginner-friendly resources with clear explanations and solved numerical problems.",
  level: 'beginner',
  availableMinutes: '60',
  goalType: 'exam-prep',
};

const EXAMPLE_PRESETS = {
  kirchhoff: {
    topic: "Kirchhoff's Laws — beginner-friendly resources with solved numerical problems for engineering exam",
    level: 'beginner', availableMinutes: '60', goalType: 'exam-prep',
  },
  fourier: {
    topic: 'Teach me Fourier Series for engineering mathematics exam',
    level: 'intermediate', availableMinutes: '45', goalType: 'exam-prep',
  },
  revision: {
    topic: "Quick revision of Ohm's Law and basic circuit theory",
    level: 'beginner', availableMinutes: '15', goalType: 'quick-revision',
  },
};

// ── Agent step config (pipeline stages with honest progress percentages) ────────
// Delays match the real backend pipeline timing (verified from test results)
const AGENT_STEPS = [
  { step: 1, text: 'Understanding your goal',        delay: 0,    pct: 5  },
  { step: 2, text: 'Mapping required concepts',      delay: 900,  pct: 14 },
  { step: 3, text: 'Generating 5 search paths',      delay: 1700, pct: 24 },
  { step: 4, text: 'Fetching resources via Webcmd',  delay: 2800, pct: 40 },
  { step: 5, text: 'Analyzing discovered resources', delay: 5500, pct: 62 },
  { step: 6, text: 'Ranking by your profile',        delay: 7800, pct: 80 },
  { step: 7, text: 'Building personalized plan',     delay: 9000, pct: 92 },
];

// ── Pill controls ──────────────────────────────────────────────────────────────
function wirePillGroup(group, attr) {
  group.querySelectorAll('.pill-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      group.querySelectorAll('.pill-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      if (attr === 'time') {
        const isCustom = btn.dataset.time === 'custom';
        customTimeGroup.classList.toggle('hidden', !isCustom);
        if (isCustom) customMinutes.focus();
      }
    });
  });
}
wirePillGroup(levelGroup, 'level');
wirePillGroup(goalGroup,  'goal');
wirePillGroup(timeGroup,  'time');

function getLevel() {
  const a = levelGroup.querySelector('.pill-btn.active');
  return a ? a.dataset.level : 'intermediate';
}

function setLevel(level) {
  levelGroup.querySelectorAll('.pill-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.level === level));
}

function getGoalType() {
  const a = goalGroup.querySelector('.pill-btn.active');
  return a ? a.dataset.goal : 'exam-prep';
}

function setGoalType(goalType) {
  goalGroup.querySelectorAll('.pill-btn').forEach(b =>
    b.classList.toggle('active', b.dataset.goal === goalType));
}

function getMinutes() {
  const a = timeGroup.querySelector('.pill-btn.active');
  if (a && a.dataset.time === 'custom') {
    const v = parseInt(customMinutes.value, 10);
    return (!isNaN(v) && v > 0) ? v : 60;
  }
  return a ? parseInt(a.dataset.time, 10) : 60;
}

function setMinutes(minutes) {
  const str = String(minutes);
  const match = [...timeGroup.querySelectorAll('.pill-btn')].find(b => b.dataset.time === str);
  if (match) {
    timeGroup.querySelectorAll('.pill-btn').forEach(b => b.classList.remove('active'));
    match.classList.add('active');
    customTimeGroup.classList.add('hidden');
  } else {
    timeGroup.querySelectorAll('.pill-btn').forEach(b =>
      b.classList.toggle('active', b.dataset.time === 'custom'));
    customTimeGroup.classList.remove('hidden');
    customMinutes.value = minutes;
  }
}

// ── Preset fill ────────────────────────────────────────────────────────────────
function applyPreset(preset) {
  topicInput.value = preset.topic;
  setLevel(preset.level);
  setMinutes(preset.availableMinutes);
  setGoalType(preset.goalType);
  topicInput.focus();
  topicInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

demoBtn.addEventListener('click', () => applyPreset(DEMO));

document.querySelectorAll('.example-chip').forEach(chip => {
  chip.addEventListener('click', () => {
    const preset = EXAMPLE_PRESETS[chip.dataset.example];
    if (preset) applyPreset(preset);
  });
});

// ── Tab management (results page) ──────────────────────────────────────────────
function activateTab(target) {
  tabButtons.forEach(b => b.classList.toggle('active', b.dataset.tab === target));
  tabContents.forEach(c => {
    const id = c.id.replace('tab-', '');
    c.classList.toggle('hidden', id !== target);
  });
}

tabButtons.forEach(btn => {
  btn.addEventListener('click', () => activateTab(btn.dataset.tab));
});

// ── Error display ──────────────────────────────────────────────────────────────
function showInlineError(msg, detail) {
  if (errorMessage) errorMessage.textContent = msg;
  if (detail) {
    errorDetailToggle.classList.remove('hidden');
    errorDetailBody.textContent = detail;
    errorDetailBody.classList.add('hidden');
    errorDetailToggle.textContent = 'Show technical details';
  } else {
    if (errorDetailToggle) errorDetailToggle.classList.add('hidden');
    if (errorDetailBody)   errorDetailBody.classList.add('hidden');
  }
  if (homeErrorCard) homeErrorCard.classList.remove('hidden');
}

if (errorDetailToggle) {
  errorDetailToggle.addEventListener('click', () => {
    const isHidden = errorDetailBody.classList.toggle('hidden');
    errorDetailToggle.textContent = isHidden ? 'Show technical details' : 'Hide technical details';
  });
}

if (errorRetryBtn) {
  errorRetryBtn.addEventListener('click', () => {
    if (homeErrorCard) homeErrorCard.classList.add('hidden');
    navigateTo(PAGE.HOME);
  });
}

// ── Agent animation (research page) ───────────────────────────────────────────
function startAgentAnimation() {
  // Reset all activity items
  document.querySelectorAll('.activity-item').forEach(el =>
    el.classList.remove('is-active', 'is-done'));

  ringFill.classList.remove('ring-complete');
  updateRing(0);
  if (agentCurrentAction) agentCurrentAction.textContent = 'Researching for you';
  if (agentQueriesEl)      agentQueriesEl.classList.add('hidden');
  if (agentQueriesListEl)  agentQueriesListEl.innerHTML = '';

  // Reset live stats
  if (statFoundEl) statFoundEl.textContent = '—';
  if (statBestEl)  statBestEl.textContent  = '—';

  // Hide completion card
  if (researchCompleteCard) researchCompleteCard.classList.add('hidden');

  stepTimers.forEach(clearTimeout);
  stepTimers = [];

  AGENT_STEPS.forEach(({ step, text, delay, pct }) => {
    const t = setTimeout(() => {
      // Mark previous step done
      const prev = document.querySelector(`.activity-item[data-step="${step - 1}"]`);
      if (prev) {
        prev.classList.remove('is-active');
        prev.classList.add('is-done');
      }
      // Mark current step active
      const cur = document.querySelector(`.activity-item[data-step="${step}"]`);
      if (cur) cur.classList.add('is-active');

      // Update eyebrow label
      if (agentCurrentAction) agentCurrentAction.textContent = text;

      // Update ring
      updateRing(pct);
    }, delay);
    stepTimers.push(t);
  });
}

function finishAgentAnimation(data) {
  stepTimers.forEach(clearTimeout);
  stepTimers = [];

  // Mark all steps done
  document.querySelectorAll('.activity-item').forEach(el => {
    el.classList.remove('is-active');
    el.classList.add('is-done');
  });

  updateRing(100);
  if (agentCurrentAction) agentCurrentAction.textContent = 'Research complete';

  // Show actual search queries
  if (data.meta.searchQueries && data.meta.searchQueries.length > 0) {
    if (agentQueriesListEl) {
      agentQueriesListEl.innerHTML = data.meta.searchQueries
        .map(q => `<span class="query-chip">${esc(q)}</span>`)
        .join('');
    }
    if (agentQueriesEl) agentQueriesEl.classList.remove('hidden');
  }
}

// ── Research page setup ────────────────────────────────────────────────────────
function setupResearchPage(body) {
  // Topic display
  if (researchTopicText) researchTopicText.textContent = body.topic;

  // Header topic (truncated)
  if (headerResearchTopic) {
    const t = body.topic;
    headerResearchTopic.textContent = t.length > 60 ? t.slice(0, 57) + '…' : t;
  }

  // Goal pills
  if (researchGoalPills) {
    const levelLabels  = { beginner: 'Beginner', intermediate: 'Undergraduate', advanced: 'Advanced' };
    const goalLabels   = { 'exam-prep': 'Exam Prep', 'quick-revision': 'Quick Revision', 'basics': 'Understand' };
    researchGoalPills.innerHTML = [
      levelLabels[body.level]            || body.level,
      body.availableMinutes + ' min',
      goalLabels[body.goalType]          || body.goalType,
    ].map(t => `<span class="research-goal-pill">${esc(t)}</span>`).join('');
  }
}

// ── Type breakdown (shown after research completes) ────────────────────────────
function renderTypeBreakdown(resources) {
  const counts = { video: 0, course: 0, article: 0, reference: 0 };
  resources.forEach(r => {
    if (counts[r.type] !== undefined) counts[r.type]++;
    else counts.article++;  // unrecognised types counted as article
  });

  const pills = Object.entries(counts)
    .filter(([, n]) => n > 0)
    .map(([type, n]) => `
      <span class="type-pill">
        <span class="type-pill-icon">${typeIcon(type)}</span>
        <span>${type.charAt(0).toUpperCase() + type.slice(1)}s</span>
        <span class="type-pill-count">${n}</span>
      </span>
    `).join('');

  if (typeBreakdownEl) typeBreakdownEl.innerHTML = pills;
}

// ── Stop reason text (honest — derived from actual API response) ───────────────
function buildStopReason(meta, resources) {
  const paths  = meta.searchQueries ? meta.searchQueries.length : 5;
  const found  = meta.totalResearchedCount || 0;
  const ranked = resources.length;
  const secs   = meta.elapsedSeconds || 0;

  return `StudyScout explored ${paths} search path${paths !== 1 ? 's' : ''} ` +
    `and analyzed ${found} candidate resource${found !== 1 ? 's' : ''} in ${secs}s. ` +
    `Research stopped after processing all search paths. ` +
    `The top ${ranked} resource${ranked !== 1 ? 's' : ''} were selected based on your level, goal, and time budget.`;
}

// ── Filters + sort ─────────────────────────────────────────────────────────────
filterBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    filterBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    currentFilter = btn.dataset.filter;
    applyFilter();
  });
});

sortSelect.addEventListener('change', () => {
  currentSort = sortSelect.value;
  renderResourceList();
});

function applyFilter() {
  resourceGrid.querySelectorAll('.resource-card').forEach(card => {
    const show = currentFilter === 'all' || card.dataset.type === currentFilter;
    card.style.display = show ? '' : 'none';
  });
}

function sortedResources() {
  if (!currentResults) return [];
  const list = [...currentResults.resources];
  if (currentSort === 'shortest') list.sort((a, b) => a.estimatedMinutes - b.estimatedMinutes);
  return list;
}

function renderResourceList() {
  resourceGrid.innerHTML = '';
  sortedResources().forEach(r => resourceGrid.appendChild(renderResourceCard(r)));
  applyFilter();
}

// ── Comparison ─────────────────────────────────────────────────────────────────
function updateCompareBar() {
  const count = selectedForCompare.size;
  if (compareCountEl) compareCountEl.textContent = `${count} selected`;
  if (compareBar)      compareBar.classList.toggle('hidden', count < 2);
  if (compareClearBtn) compareClearBtn.classList.toggle('hidden', count === 0);
}

compareBtn.addEventListener('click', () => {
  if (!currentResults) return;
  const selected = currentResults.resources.filter(r => selectedForCompare.has(r.url));
  renderComparisonTable(selected);
  comparisonWrap.classList.remove('hidden');
  comparisonWrap.scrollIntoView({ behavior: 'smooth', block: 'start' });
});

comparisonClose.addEventListener('click', () => comparisonWrap.classList.add('hidden'));

compareClearBtn.addEventListener('click', () => {
  selectedForCompare.clear();
  resourceGrid.querySelectorAll('.resource-card').forEach(c => {
    c.classList.remove('selected-for-compare');
    const cb = c.querySelector('.compare-checkbox');
    if (cb) cb.checked = false;
  });
  updateCompareBar();
});

// ── Alternative search ─────────────────────────────────────────────────────────
const ALT_REASONS = {
  numericals: 'Too theoretical — need solved numericals',
  shorter:    'Too long — need shorter resource',
  video:      'Need a video explanation instead',
  simpler:    'Too complex — need simpler explanation',
  notes:      'Need notes or article format',
};

alternativeBack.addEventListener('click', () => {
  alternativeResult.classList.add('hidden');
  alternativeGrid.innerHTML = '';
});

async function searchAlternative(resource, reason, constraintKey) {
  const goal = currentResults.goal;
  const constraint = ALT_REASONS[constraintKey] ?? reason;
  const newTopic = `${goal.topic} — ${constraint}`;

  alternativeResult.classList.remove('hidden');
  alternativeGrid.innerHTML = `<div style="grid-column:1/-1;padding:30px;text-align:center;color:var(--text-400)">Searching webcmd for alternatives: "${esc(constraint)}"...</div>`;
  alternativeResult.scrollIntoView({ behavior: 'smooth', block: 'start' });

  try {
    const res = await fetch('/api/research', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ topic: newTopic, level: goal.level, availableMinutes: goal.availableMinutes, goalType: goal.goalType }),
    });

    const data = await res.json();
    if (!res.ok || !data.resources || data.resources.length === 0) {
      alternativeGrid.innerHTML = `<div style="grid-column:1/-1;padding:20px;color:var(--text-400)">No alternatives found. Try rephrasing.</div>`;
      return;
    }

    alternativeGrid.innerHTML = '';
    const alts = data.resources.filter(r => r.url !== resource.url).slice(0, 3);
    alts.forEach(r => alternativeGrid.appendChild(renderResourceCard(r, false)));

    if (alts.length === 0) {
      alternativeGrid.innerHTML = `<div style="padding:20px;color:var(--text-400)">No different alternatives found for this constraint.</div>`;
    }
  } catch (err) {
    alternativeGrid.innerHTML = `<div style="grid-column:1/-1;padding:20px;color:var(--text-400)">Search failed: ${esc(err.message)}</div>`;
  }
}

// ── Badge CSS class ────────────────────────────────────────────────────────────
function badgeClass(badge) {
  const map = {
    'Best Match':        'badge-best',
    'Quick Watch':       'badge-quick',
    'Structured Course': 'badge-course',
    'In-Depth Course':   'badge-course',
    'Reference':         'badge-ref',
  };
  return map[badge] ?? '';
}

// ── Render resource card ───────────────────────────────────────────────────────
function renderResourceCard(resource, withCompare = true) {
  const card = document.createElement('article');
  card.className = 'resource-card';
  card.dataset.type = resource.type;
  card.dataset.url  = resource.url;

  const bClass     = badgeClass(resource.badge);
  const score      = Math.round(resource.score);
  const reasons    = (resource.reasons ?? []).slice(0, 3);
  const summaryTxt = resource.summary
    ? resource.summary.slice(0, 180)
    : `${(resource.type || 'Resource').charAt(0).toUpperCase() + resource.type.slice(1)} from ${resource.source}`;

  const isBrowserMode = resource.fetchMode === 'browser';
  const browserNote = isBrowserMode
    ? `<div class="browser-recovery-note">${ICONS.bolt} ${esc(resource.source)} retrieved via Webcmd browser session (richer content)</div>`
    : '';

  const reasonsHtml = reasons.length > 0
    ? `<div class="resource-reasons">${reasons.map(r =>
        `<div class="resource-reason"><span class="reason-check">✓</span><span>${esc(r)}</span></div>`
      ).join('')}</div>`
    : '';

  const compareCheckHtml = withCompare
    ? `<input type="checkbox" class="compare-checkbox" title="Select for comparison" aria-label="Select for comparison" />`
    : '';

  const dropdownId = `alt-dd-${esc(resource.url).replace(/\W/g,'').slice(0,20)}`;
  const altDropdownHtml = `
    <div class="alt-dropdown hidden" id="${dropdownId}">
      <button class="alt-dropdown-item" data-constraint="numericals">Too theoretical — need numericals</button>
      <button class="alt-dropdown-item" data-constraint="shorter">Too long — need shorter</button>
      <button class="alt-dropdown-item" data-constraint="video">Need video instead</button>
      <button class="alt-dropdown-item" data-constraint="simpler">Too complex — need simpler</button>
      <button class="alt-dropdown-item" data-constraint="notes">Need notes / article</button>
    </div>
  `;

  card.innerHTML = `
    <div class="resource-card-top">
      <div class="resource-top-left">
        <span class="resource-type-icon">${typeIcon(resource.type)}</span>
        <span class="resource-badge ${bClass}">${esc(resource.badge)}</span>
      </div>
      ${compareCheckHtml}
    </div>

    <div class="resource-source">${esc(resource.source)}</div>
    <div class="resource-title">${esc(resource.title || resource.source || 'Resource')}</div>

    ${browserNote}

    ${summaryTxt ? `<div class="resource-summary">${esc(summaryTxt)}</div>` : ''}

    ${reasonsHtml}

    <div class="resource-meta">
      <span class="resource-time">${ICONS.clock} ${resource.estimatedMinutes} min</span>
      <div class="resource-score-wrap">
        <span class="resource-score-num">${score}% match</span>
        <div class="score-bar">
          <div class="score-fill" style="width:${score}%"></div>
        </div>
      </div>
    </div>

    <div class="resource-card-actions">
      <a class="resource-link" href="${safeURL(resource.url)}" target="_blank" rel="noopener noreferrer">
        Open resource ↗
      </a>
      <div style="position:relative">
        <button class="btn-alternative" data-url="${esc(resource.url)}">
          Find alternative ▾
        </button>
        ${altDropdownHtml}
      </div>
    </div>
  `;

  const checkbox = card.querySelector('.compare-checkbox');
  if (checkbox) {
    checkbox.addEventListener('change', () => {
      if (checkbox.checked) {
        selectedForCompare.add(resource.url);
        card.classList.add('selected-for-compare');
      } else {
        selectedForCompare.delete(resource.url);
        card.classList.remove('selected-for-compare');
      }
      updateCompareBar();
    });
  }

  const altBtn = card.querySelector('.btn-alternative');
  const altDD  = card.querySelector('.alt-dropdown');
  if (altBtn && altDD) {
    altBtn.addEventListener('click', e => {
      e.stopPropagation();
      document.querySelectorAll('.alt-dropdown').forEach(d => {
        if (d !== altDD) d.classList.add('hidden');
      });
      altDD.classList.toggle('hidden');
    });

    altDD.querySelectorAll('.alt-dropdown-item').forEach(item => {
      item.addEventListener('click', () => {
        altDD.classList.add('hidden');
        const constraint = item.dataset.constraint;
        // Navigate to resources tab in results page, then fire alternative search
        activateTab('resources');
        searchAlternative(resource, item.textContent.trim(), constraint);
      });
    });
  }

  return card;
}

document.addEventListener('click', () => {
  document.querySelectorAll('.alt-dropdown').forEach(d => d.classList.add('hidden'));
});

// ── Render comparison table ────────────────────────────────────────────────────
function renderComparisonTable(resources) {
  const ROWS = [
    ['Source',      r => esc(r.source)],
    ['Type',        r => esc(r.type)],
    ['Est. time',   r => `${r.estimatedMinutes} min`],
    ['Match score', r => `${Math.round(r.score)}%`],
    ['Fetch mode',  r => r.fetchMode === 'browser' ? 'Browser (Webcmd)' : 'Web fetch'],
    ['Best for',    r => esc(r.badge)],
    ['Summary',     r => r.summary ? esc(r.summary.slice(0, 80)) + '…' : 'Not available'],
  ];

  const headerCells = ['Attribute', ...resources.map((r, i) => `<strong>#${i+1} ${esc(r.source)}</strong>`)].join('</th><th>');
  const bodyRows = ROWS.map(([label, fn]) => {
    const cells = resources.map(r => `<td>${fn(r)}</td>`).join('');
    return `<tr><td class="col-label">${label}</td>${cells}</tr>`;
  }).join('');

  const bestScore   = Math.max(...resources.map(r => r.score));
  const bestForScore = resources.findIndex(r => r.score === bestScore);
  const shortest    = resources.reduce((a, b) => a.estimatedMinutes < b.estimatedMinutes ? a : b);
  const bestForTime = resources.indexOf(shortest);

  const highlightRow = `
    <tr>
      <td class="col-label">Recommended if…</td>
      ${resources.map((r, i) => `<td class="${i === bestForScore ? 'best-cell' : ''}">${
        i === bestForScore ? 'Best overall match' :
        i === bestForTime  ? 'Shortest / quickest' :
        r.type === 'video' ? 'Prefer video' : 'Prefer reading'
      }</td>`).join('')}
    </tr>
  `;

  comparisonTable.innerHTML = `
    <thead><tr><th>${headerCells}</th></tr></thead>
    <tbody>${bodyRows}${highlightRow}</tbody>
  `;
}

// ── Render suggested learning sequence ──────────────────────────────────────────
function renderConceptMap(goal) {
  const kws = (goal.keywords || []).slice(0, 4);
  const topicShort = kws.length >= 2 ? kws.slice(0, 2).join(' + ') : goal.topic.split(' ').slice(0, 4).join(' ');

  const stages = [];
  stages.push({ label: 'Fundamentals', type: 'prerequisite', hint: 'Build on basics' });

  if (topicShort) {
    stages.push({ label: topicShort, type: 'core', hint: 'Your main topic' });
  } else {
    stages.push({ label: 'Core Concept', type: 'core', hint: 'Your main topic' });
  }

  const goalTypes = {
    'exam-prep':      { label: 'Practice Problems', type: 'exam',    hint: 'Apply what you learn with problems' },
    'quick-revision': { label: 'Key Facts',          type: 'revise',  hint: 'Review essential points quickly' },
    'basics':         { label: 'Deeper Practice',    type: 'practice',hint: 'Work through exercises' },
  };
  const gt = goalTypes[goal.goalType] || goalTypes['basics'];
  stages.push({ label: gt.label, type: gt.type, hint: gt.hint });

  let finalLabel = 'Apply', finalType = 'practice', finalHint = "Use what you've learned";
  if (goal.goalType === 'exam-prep')      { finalLabel = 'Exam Practice'; finalType = 'exam';    finalHint = 'Test yourself with problems'; }
  else if (goal.goalType === 'quick-revision') { finalLabel = 'Quick Review';  finalType = 'revise';  finalHint = 'Recall key facts'; }
  else if (goal.goalType === 'basics')    { finalLabel = 'Hands-on';     finalType = 'practice'; finalHint = 'Build something with the concepts'; }
  stages.push({ label: finalLabel, type: finalType, hint: finalHint });

  conceptMapEl.innerHTML = stages.map((node, i) => `
    <div class="concept-node">
      <div class="concept-box ${node.type}" title="${esc(node.hint)}">${esc(node.label)}</div>
      <div class="concept-label">${esc(node.hint)}</div>
    </div>
    ${i < stages.length - 1 ? `<div class="concept-arrow"><svg width="18" height="18" viewBox="0 0 24 24" fill="none"><path d="M5 12h14M13 6l6 6-6 6" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></div>` : ''}
  `).join('');
}

// ── Render stats grid (Overview) ────────────────────────────────────────────────
function renderStatsGrid(resources, meta) {
  const topScore  = resources.length ? Math.max(...resources.map(r => r.score)) : 0;
  const webcmdMode = meta.webcmdMode || [];
  const browserUsed = webcmdMode.some(m => m === 'browser');

  const stats = [
    { icon: ICONS.search, value: meta.searchQueries.length,  label: 'Search paths explored' },
    { icon: ICONS.stack,  value: meta.totalResearchedCount,  label: 'Resources researched' },
    { icon: ICONS.target, value: `${topScore}%`,             label: 'Top match' },
    { icon: browserUsed ? ICONS.bolt : ICONS.globe,
      value: `${meta.elapsedSeconds}s`,
      label: browserUsed ? 'Research time · browser used' : 'Research time · web fetch' },
  ];

  statsGridEl.innerHTML = stats.map(s => `
    <div class="stat-card">
      <div class="stat-card-icon">${s.icon}</div>
      <div class="stat-card-value">${esc(String(s.value))}</div>
      <div class="stat-card-label">${esc(s.label)}</div>
    </div>
  `).join('');
}

// ── Render top resource preview ─────────────────────────────────────────────────
function renderTopResource(resource) {
  const reasons = (resource.reasons ?? []).slice(0, 4);
  const reasonsHtml = reasons.length > 0
    ? reasons.map(r => `<div class="resource-reason"><span class="reason-check">✓</span><span>${esc(r)}</span></div>`).join('')
    : `<div class="resource-reason"><span>No specific match reasons returned.</span></div>`;

  topResourceEl.innerHTML = `
    <div class="top-resource-card">
      <span class="top-resource-eyebrow">${esc(resource.badge || 'Best match')}</span>
      <div class="top-resource-row1">
        <span class="top-resource-source">${esc(resource.source)}</span>
        <span class="top-resource-score">${Math.round(resource.score)}<span>% match</span></span>
      </div>
      <div class="top-resource-title">${esc(resource.title)}</div>
      ${resource.summary ? `<div class="top-resource-summary">${esc(resource.summary.slice(0, 220))}</div>` : ''}
      <div class="top-resource-reasons">${reasonsHtml}</div>
      <div class="top-resource-footer">
        <a class="btn btn-primary btn-sm" href="${safeURL(resource.url)}" target="_blank" rel="noopener noreferrer">Open resource ↗</a>
        <span class="top-resource-meta">${ICONS.clock} ${resource.estimatedMinutes} min</span>
        <span class="top-resource-meta">${ICONS.globe} Discovered via webcmd</span>
      </div>
    </div>
  `;
}

// ── Render study plan ──────────────────────────────────────────────────────────
function renderStudyPlan(plan, goal) {
  let cumulative = 0;

  const slotsHtml = plan.slots.map(slot => {
    const start   = cumulative;
    const end     = cumulative + slot.allocatedMinutes;
    cumulative    = end;
    const timeRange = `${pad(start)}–${pad(end)} min`;
    return `
      <div class="plan-slot">
        <div class="slot-left">
          <div class="slot-num">${slot.slotNumber}</div>
          <div class="slot-connector"></div>
        </div>
        <div class="slot-body">
          <div class="slot-time-range">${timeRange}</div>
          <div class="slot-activity-label">${esc(slot.activity)}</div>
          <div class="slot-title">${esc(slot.title)}</div>
          <div class="slot-source">via ${esc(slot.source)}</div>
          <div class="slot-tip">${esc(slot.tip)}</div>
        </div>
        <div class="slot-right">
          <div class="slot-mins">${slot.allocatedMinutes}</div>
          <div class="slot-mins-label">min</div>
        </div>
      </div>
    `;
  }).join('');

  const tipsHtml = plan.generalTips.map(t => `<li>${esc(t)}</li>`).join('');

  studyPlanWrap.innerHTML = `
    <div class="plan-header">
      <div class="plan-title">Your ${goal.availableMinutes}-minute study plan</div>
      <div class="plan-stats">
        <span class="plan-stat-pill">${plan.slots.length} resources</span>
        <span class="plan-stat-pill">${plan.allocatedMinutes} min study</span>
        <span class="plan-stat-pill">${plan.bufferMinutes} min buffer</span>
      </div>
    </div>
    <div class="plan-timeline">${slotsHtml}</div>
    <div class="plan-buffer-slot">${plan.bufferMinutes} min buffer — reserved for breaks, review, or running over</div>
    <div class="plan-tips">
      <h3>Study tips</h3>
      <ul>${tipsHtml}</ul>
    </div>
  `;
}

// ── Render goal bar ────────────────────────────────────────────────────────────
function renderGoalBar(goal) {
  goalBarEl.innerHTML = `
    <div class="goal-topic">${esc(goal.topic.slice(0, 80))}${goal.topic.length > 80 ? '…' : ''}</div>
    <span class="goal-pill">${esc(goal.levelLabel)}</span>
    <span class="goal-pill">${goal.availableMinutes} min</span>
    <span class="goal-pill">${esc(goal.goalLabel)}</span>
  `;

  // Update header results meta
  if (headerResultsMeta) {
    headerResultsMeta.textContent = `${goal.topic.slice(0, 40)}${goal.topic.length > 40 ? '…' : ''} · ${goal.availableMinutes}m`;
  }
}

// ── Render all results ─────────────────────────────────────────────────────────
function renderResults(data) {
  currentResults = data;

  renderGoalBar(data.goal);
  renderResourceList();
  if (resourcesCountEl) resourcesCountEl.textContent = data.resources.length;
  comparisonWrap.classList.add('hidden');
  alternativeResult.classList.add('hidden');
  updateCompareBar();
  renderStatsGrid(data.resources, data.meta);
  renderTopResource(data.resources[0]);
  renderConceptMap(data.goal);
  renderStudyPlan(data.studyPlan, data.goal);
  activateTab('overview');
}

// ── Main research function ─────────────────────────────────────────────────────
async function doResearch(body) {
  pendingBody = body;

  // Navigate to research page
  navigateTo(PAGE.RESEARCH);
  setupResearchPage(body);
  startAgentAnimation();
  startElapsedTimer();

  if (homeErrorCard) homeErrorCard.classList.add('hidden');

  abortController = new AbortController();

  try {
    const res = await fetch('/api/research', {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(body),
      signal:  abortController.signal,
    });

    const data = await res.json();
    stopElapsedTimer();

    if (!res.ok) {
      // Navigate back to home and show error
      pendingBody = null;
      navigateTo(PAGE.HOME);
      showInlineError(data.error ?? `Server error (${res.status}). Please try again.`, data.detail);
      return;
    }

    if (!data.resources || data.resources.length === 0) {
      pendingBody = null;
      navigateTo(PAGE.HOME);
      showInlineError('No resources were found. Try a more specific topic or check your internet connection.');
      return;
    }

    // Update live stats with real values
    if (statFoundEl) statFoundEl.textContent = String(data.meta.totalResearchedCount);
    if (statBestEl) {
      const topScore = Math.max(...data.resources.map(r => r.score));
      statBestEl.textContent = Math.round(topScore) + '%';
    }
    if (statTimeEl) statTimeEl.textContent = data.meta.elapsedSeconds + 's';

    // Finish animation
    finishAgentAnimation(data);

    // Render type breakdown + stop reason
    renderTypeBreakdown(data.resources);
    if (researchStopReason) {
      researchStopReason.textContent = buildStopReason(data.meta, data.resources);
    }

    // Pre-render all results (so results page is ready when user clicks)
    renderResults(data);

    // Show completion card
    if (researchCompleteCard) researchCompleteCard.classList.remove('hidden');
    researchCompleteCard.scrollIntoView({ behavior: 'smooth', block: 'center' });

  } catch (err) {
    stopElapsedTimer();
    if (err.name === 'AbortError') return;  // user cancelled — already navigated away
    console.error('[StudyScout] fetch error:', err);
    pendingBody = null;
    navigateTo(PAGE.HOME);
    showInlineError('Could not reach the StudyScout server. Is it running?');
  }
}

// ── "View learning plan" CTA ───────────────────────────────────────────────────
if (btnViewResults) {
  btnViewResults.addEventListener('click', () => {
    navigateTo(PAGE.RESULTS);
  });
}

// ── Cancel research ────────────────────────────────────────────────────────────
if (btnCancelResearch) {
  btnCancelResearch.addEventListener('click', () => {
    if (abortController) abortController.abort();
    stopElapsedTimer();
    stepTimers.forEach(clearTimeout);
    stepTimers = [];
    pendingBody = null;
    navigateTo(PAGE.HOME);
  });
}

// ── "← New research" buttons ──────────────────────────────────────────────────
document.getElementById('btn-new-research').addEventListener('click', () => {
  navigateTo(PAGE.HOME);
});

startOverBtn.addEventListener('click', () => {
  navigateTo(PAGE.HOME);
  resourceGrid.innerHTML = '';
  studyPlanWrap.innerHTML = '';
  currentResults = null;
  selectedForCompare.clear();
  topicInput.focus();
});

// Logo → home
document.getElementById('logo-home-btn').addEventListener('click', () => {
  navigateTo(PAGE.HOME);
});

// ── Form submission ────────────────────────────────────────────────────────────
researchBtn.addEventListener('click', async () => {
  const topic = topicInput.value.trim();
  if (!topic) {
    topicInput.focus();
    topicInput.style.borderColor = 'var(--red)';
    setTimeout(() => { topicInput.style.borderColor = ''; }, 2000);
    return;
  }
  if (homeErrorCard) homeErrorCard.classList.add('hidden');

  await doResearch({
    topic,
    level:            getLevel(),
    availableMinutes: getMinutes(),
    goalType:         getGoalType(),
  });
});

topicInput.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') researchBtn.click();
});

// ── PDF Syllabus Upload ────────────────────────────────────────────────────────
async function handleSyllabusFile(file) {
  if (!file) return;

  const hint = document.getElementById('upload-hint');
  const originalHint = hint.textContent;
  hint.textContent = `Processing ${file.name}...`;
  syllabusPanel.classList.add('hidden');

  const formData = new FormData();
  formData.append('syllabus', file);

  try {
    const res = await fetch('/api/upload-syllabus', { method: 'POST', body: formData });
    const data = await res.json();

    if (!res.ok || data.error) {
      hint.textContent = `Could not parse PDF: ${data.error ?? 'Unknown error'}. Enter topic manually.`;
      syllabusFile.value = '';
      return;
    }

    if (data.warning) {
      hint.textContent = data.warning;
    } else {
      hint.textContent = `${data.topics.length} topics detected`;
    }

    if (!data.topics || data.topics.length === 0) return;

    syllabusFilename.textContent = file.name;

    syllabusTopicsEl.innerHTML = data.topics.map((topic, i) => `
      <div class="syllabus-topic selected" data-index="${i}">
        <input type="checkbox" checked id="stopic-${i}" />
        <div class="syllabus-topic-text">
          <label for="stopic-${i}" style="cursor:pointer">${esc(topic)}</label>
        </div>
      </div>
    `).join('');

    syllabusTopicsEl.querySelectorAll('.syllabus-topic').forEach(el => {
      el.addEventListener('click', e => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'LABEL') return;
        const cb = el.querySelector('input[type="checkbox"]');
        cb.checked = !cb.checked;
        el.classList.toggle('selected', cb.checked);
      });
      el.querySelector('input').addEventListener('change', e => {
        el.classList.toggle('selected', e.target.checked);
      });
    });

    syllabusPanel.classList.remove('hidden');
    syllabusFile.value = '';

  } catch (err) {
    hint.textContent = 'PDF parsing failed. Enter topic manually.';
    syllabusFile.value = '';
  }
}

syllabusFile.addEventListener('change', () => handleSyllabusFile(syllabusFile.files[0]));

['dragenter', 'dragover'].forEach(evt => {
  uploadZone.addEventListener(evt, e => {
    e.preventDefault();
    uploadZone.classList.add('is-dragover');
  });
});
['dragleave', 'drop'].forEach(evt => {
  uploadZone.addEventListener(evt, e => {
    e.preventDefault();
    uploadZone.classList.remove('is-dragover');
  });
});
uploadZone.addEventListener('drop', e => {
  const file = e.dataTransfer?.files?.[0];
  if (file && (file.type === 'application/pdf' || file.name.endsWith('.pdf'))) {
    handleSyllabusFile(file);
  }
});

syllabusClose.addEventListener('click', () => syllabusPanel.classList.add('hidden'));

syllabusResearchBtn.addEventListener('click', async () => {
  const selected = [...syllabusTopicsEl.querySelectorAll('.syllabus-topic.selected')]
    .map(el => el.querySelector('label')?.textContent || el.querySelector('.syllabus-topic-text')?.textContent || '');

  if (selected.length === 0) {
    alert('Select at least one topic.');
    return;
  }

  const combinedTopic = selected.slice(0, 5).join(', ');
  topicInput.value = combinedTopic;
  syllabusPanel.classList.add('hidden');

  await doResearch({
    topic: combinedTopic,
    level: getLevel(),
    availableMinutes: getMinutes(),
    goalType: getGoalType(),
  });
});