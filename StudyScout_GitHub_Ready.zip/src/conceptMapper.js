'use strict';

/**
 * conceptMapper.js
 *
 * Maps a StudyGoal to a list of concrete search queries.
 *
 * Design principles:
 * - Rule-based by default (no LLM required)
 * - If GEMINI_API_KEY is present in env, the LLM path is used instead
 * - Returns 3–5 search terms that target real educational resources
 */

/**
 * Well-known educational domains to seed targeted searches.
 * These surface reliably in DuckDuckGo HTML results.
 */
const EDUCATIONAL_SOURCES = [
  'site:youtube.com',
  'site:khanacademy.org',
  'site:wikipedia.org',
];

/**
 * Goal-type suffixes that shape what kind of content surfaces first.
 */
const GOAL_SUFFIXES = {
  'basics':         ['explained simply', 'introduction tutorial', 'beginner guide'],
  'exam-prep':      ['exam questions', 'engineering exam tutorial', 'solved examples'],
  'quick-revision': ['quick summary', 'revision notes', 'cheat sheet overview'],
};

/**
 * Level qualifiers that help filter result relevance.
 */
const LEVEL_QUALIFIERS = {
  beginner:     '',
  intermediate: 'engineering',
  advanced:     'advanced university lecture',
};

/**
 * Build rule-based search queries from a StudyGoal.
 *
 * @param {import('./goalParser').StudyGoal} goal
 * @returns {string[]} Array of search query strings (3–5 items)
 */
function buildRuleBasedQueries(goal) {
  const { topic, keywords, level, goalType } = goal;
  const levelQual = LEVEL_QUALIFIERS[level] || '';
  const suffixes  = GOAL_SUFFIXES[goalType] || GOAL_SUFFIXES['basics'];

  // Use cleaned keywords if the topic was a sentence, otherwise use topic directly.
  // Cap at 5 keywords to keep queries tight and readable.
  const coreQuery = keywords.length >= 2
    ? keywords.slice(0, 5).join(' ')
    : topic;

  const queries = [];

  // Query 1: YouTube-targeted with goal suffix
  queries.push(`${coreQuery} ${suffixes[0]} ${EDUCATIONAL_SOURCES[0]}`);

  // Query 2: Khan Academy targeted
  queries.push(`${coreQuery} ${suffixes[1] || suffixes[0]} ${EDUCATIONAL_SOURCES[1]}`);

  // Query 3: General educational search with level qualifier
  const levelPart = levelQual ? `${levelQual} ` : '';
  queries.push(`${levelPart}${coreQuery} ${suffixes[2] || suffixes[0]}`);

  // Query 4: Wikipedia for foundational context (useful for basics + exam-prep)
  if (goalType !== 'quick-revision') {
    queries.push(`${coreQuery} ${EDUCATIONAL_SOURCES[2]}`);
  }

  // Query 5: General tutorial fallback
  queries.push(`learn ${coreQuery} ${levelPart}tutorial`);

  return queries.slice(0, 5);
}

/**
 * Map a StudyGoal to search queries.
 * Falls back to rule-based if GEMINI_API_KEY is not configured.
 *
 * @param {import('./goalParser').StudyGoal} goal
 * @returns {Promise<string[]>}
 */
async function mapGoalToQueries(goal) {
  // LLM path: available when GEMINI_API_KEY is set (future enhancement)
  if (process.env.GEMINI_API_KEY) {
    try {
      return await buildLLMQueries(goal);
    } catch (err) {
      console.warn('[conceptMapper] LLM query generation failed, falling back to rules:', err.message);
    }
  }

  return buildRuleBasedQueries(goal);
}

/**
 * LLM-powered query generation (stub — activated when GEMINI_API_KEY is set).
 * Dropped in here cleanly without touching any other file.
 *
 * @param {import('./goalParser').StudyGoal} goal
 * @returns {Promise<string[]>}
 */
async function buildLLMQueries(goal) {
  // This stub will be replaced with real Gemini API call in a future step.
  // For now it throws so the rule-based fallback always runs.
  throw new Error('LLM query generation not yet implemented.');
}

module.exports = { mapGoalToQueries };
