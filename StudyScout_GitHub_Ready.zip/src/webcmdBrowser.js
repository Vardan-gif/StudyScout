'use strict';

/**
 * webcmdBrowser.js
 *
 * ┌──────────────────────────────────────────────────────────────────────┐
 * │  WEBCMD INTEGRATION LAYER — ONLY FILE THAT CALLS THE WEBCMD CLI      │
 * │  All webcmd invocations are isolated here.                           │
 * │  No other module should shell out to webcmd directly.                │
 * └──────────────────────────────────────────────────────────────────────┘
 *
 * Provides two methods:
 *   fetchURL(url)         — uses `webcmd web fetch` (no browser, fast)
 *   browserFetch(url)     — uses `webcmd browser run` (Playwright/Cloak, fallback)
 *   smartFetch(url)       — auto-selects best method
 *
 * Both return a FetchResult object.
 *
 * Webcmd version: 0.8.4
 *
 * WINDOWS NOTE:
 * On Windows, npm global installs produce webcmd.cmd / webcmd.ps1 shims.
 * These cannot be used with child_process.execFile directly (ENOENT / EINVAL).
 * We resolve and call `node <webcmd-main.js>` directly instead, bypassing shims.
 */

const { execFile } = require('child_process');
const { promisify } = require('util');
const path = require('path');
const fs   = require('fs');

const execFileAsync = promisify(execFile);

// ── Resolve the webcmd executable ──────────────────────────────────────────────
//
// Strategy:
//  1. Find webcmd's main.js in the npm global node_modules directory.
//     This lets us call: node <main.js> [args...]  — no shell shim needed.
//  2. If not found, fall back to cmd.exe /c webcmd (slower, works everywhere).
//
function resolveWebcmdInvocation() {
  const npms = [
    process.env.APPDATA,
    process.env.USERPROFILE ? path.join(process.env.USERPROFILE, 'AppData', 'Roaming') : null,
  ].filter(Boolean);

  for (const npmRoot of npms) {
    const candidate = path.join(npmRoot, 'npm', 'node_modules', '@agentrhq', 'webcmd', 'dist', 'src', 'main.js');
    if (fs.existsSync(candidate)) {
      console.log(`[webcmd] ✓ Resolved: node ${candidate}`);
      return { bin: process.execPath, argPrefix: [candidate] };
    }
  }

  // Fallback: use cmd.exe /c to invoke webcmd.cmd from PATH
  console.warn('[webcmd] main.js not found at npm paths, falling back to: cmd.exe /c webcmd');
  return { bin: 'cmd.exe', argPrefix: ['/c', 'webcmd'] };
}

const WEBCMD = resolveWebcmdInvocation();

/**
 * Execute a webcmd command by prepending our resolved invocation prefix.
 *
 * @param {string[]} args      - e.g. ['web', 'fetch', '--url', ...]
 * @param {Object}  [opts]     - execFile options (timeout, maxBuffer, input)
 * @returns {Promise<{stdout: string, stderr: string}>}
 */
function runWebcmd(args, opts = {}) {
  const fullArgs = [...WEBCMD.argPrefix, ...args];
  return execFileAsync(WEBCMD.bin, fullArgs, {
    maxBuffer: 10 * 1024 * 1024,
    ...opts,
  });
}

// ── Config ─────────────────────────────────────────────────────────────────────
const FETCH_TIMEOUT    = parseInt(process.env.WEBCMD_FETCH_TIMEOUT, 10) || 30;
const MAX_CHARS        = parseInt(process.env.WEBCMD_MAX_CHARS, 10) || 15000;
const BROWSER_PROFILE  = 'studyscout';

// ── Typedefs ───────────────────────────────────────────────────────────────────
/**
 * @typedef {Object} FetchResult
 * @property {boolean} success
 * @property {string}  url          - The URL that was fetched
 * @property {string}  text         - Extracted text (markdown / article / raw)
 * @property {string}  mode         - 'fetch' | 'browser'
 * @property {string}  [error]      - Error message (only on failure)
 */

/**
 * Build a DuckDuckGo HTML search URL.
 * The HTML endpoint is publicly fetchable without JS or auth.
 */
function buildDuckDuckGoURL(query) {
  return `https://duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
}

/**
 * Primary fetch: calls `webcmd web fetch --url <url> -f json`.
 * No browser session. Fast and reliable for public pages.
 *
 * CLI: node <main.js> web fetch --url <url> --max-chars <n> --timeout <n> -f json
 *
 * @param {string} url
 * @returns {Promise<FetchResult>}
 */
async function fetchURL(url) {
  const targetURL = url.startsWith('http') ? url : buildDuckDuckGoURL(url);

  const args = [
    'web', 'fetch',
    '--url', targetURL,
    '--max-chars', String(MAX_CHARS),
    '--timeout', String(FETCH_TIMEOUT),
    '-f', 'json',
  ];

  console.log(`[webcmd] web fetch → ${targetURL}`);

  try {
    const { stdout } = await runWebcmd(args, {
      timeout: (FETCH_TIMEOUT + 15) * 1000,
    });

    // webcmd -f json wraps results in an array
    const parsed = JSON.parse(stdout);
    const item   = Array.isArray(parsed) ? parsed[0] : parsed;

    // The content field holds the extracted article/markdown text
    const text = item?.content ?? item?.text ?? item?.body ?? stdout;

    return {
      success: true,
      url: targetURL,
      text: typeof text === 'string' ? text : JSON.stringify(text),
      mode: 'fetch',
    };
  } catch (err) {
    console.warn(`[webcmd] web fetch failed for ${targetURL}:`, err.message);
    return {
      success: false,
      url: targetURL,
      text: '',
      mode: 'fetch',
      error: err.message,
    };
  }
}

/**
 * Fallback fetch: uses `webcmd browser run` (Playwright/Cloak).
 *
 * Used when fetchURL returns a 403, Cloudflare block, or thin content
 * from a JS-rendered page. Creates a named browser session, navigates,
 * extracts text, then closes the session.
 *
 * CLI sequence:
 *   node <main.js> profile create studyscout
 *   node <main.js> --profile studyscout session create studyscout-N -f json
 *   node <main.js> --profile studyscout --session <id> browser run --stdin --no-snapshot-diff -f json
 *   node <main.js> --profile studyscout session close <id>
 *
 * @param {string} url - A fully-qualified HTTPS URL
 * @returns {Promise<FetchResult>}
 */
async function browserFetch(url) {
  let sessionId = null;

  try {
    // Step 1: Ensure the Cloak browser profile exists (idempotent)
    await runWebcmd(['profile', 'create', BROWSER_PROFILE], {
      timeout: 15000,
    }).catch(() => { /* profile may already exist */ });

    // Step 2: Create a named browser session
    const sessionName = `scout-${Date.now()}`;
    console.log(`[webcmd] browser session create "${sessionName}" for → ${url}`);

    const { stdout: sessionOut } = await runWebcmd([
      '--profile', BROWSER_PROFILE,
      'session', 'create', sessionName,
      '-f', 'json',
    ], { timeout: 25000 });

    const sessionData = JSON.parse(sessionOut);
    const sessionItem = Array.isArray(sessionData) ? sessionData[0] : sessionData;
    sessionId = sessionItem?.id ?? sessionItem?.sessionId ?? sessionItem?.name;

    if (!sessionId) {
      throw new Error(`Could not parse session ID from: ${sessionOut.slice(0, 200)}`);
    }

    console.log(`[webcmd] browser session: ${sessionId}`);

    // Step 3: Run Playwright script
    // Note: browser run executes in QuickJS — Buffer/require/fs are NOT available
    const playwrightScript = `
await page.goto(${JSON.stringify(url)}, { waitUntil: 'domcontentloaded', timeout: 25000 });
const title = await page.title();
const text  = await page.evaluate(() => {
  ['nav', 'footer', 'header', 'aside', '.ad', '#ad', '[class*="ad-"]'].forEach(sel => {
    document.querySelectorAll(sel).forEach(el => el.remove());
  });
  return (document.body?.innerText ?? '').slice(0, 14000);
});
return { title, text, url: page.url() };
`;

    const { stdout: runOut } = await runWebcmd([
      '--profile', BROWSER_PROFILE,
      '--session', sessionId,
      'browser', 'run',
      '--stdin',
      '--no-snapshot-diff',
      '-f', 'json',
    ], {
      input: playwrightScript,
      timeout: 45000,
    });

    const runResult  = JSON.parse(runOut);
    const runItem    = Array.isArray(runResult) ? runResult[0] : runResult;
    const text       = runItem?.result?.text ?? runItem?.text ?? '';

    return {
      success: true,
      url,
      text: typeof text === 'string' ? text : JSON.stringify(text),
      mode: 'browser',
    };

  } catch (err) {
    console.warn(`[webcmd] browser fetch failed for ${url}:`, err.message);
    return {
      success: false,
      url,
      text: '',
      mode: 'browser',
      error: err.message,
    };
  } finally {
    // Step 4: Always clean up the session
    if (sessionId) {
      runWebcmd([
        '--profile', BROWSER_PROFILE,
        'session', 'close', sessionId,
      ]).catch(() => { /* non-fatal */ });
    }
  }
}

/**
 * Smart fetch: tries `webcmd web fetch` first, falls back to `browser run`
 * if the result is empty or too thin.
 *
 * @param {string} url
 * @returns {Promise<FetchResult>}
 */
async function smartFetch(url) {
  const result = await fetchURL(url);
  if (result.success && result.text.length > 300) return result;

  console.log(`[webcmd] Light fetch insufficient (${result.text.length} chars), falling back to browser for: ${url}`);
  return browserFetch(url);
}

module.exports = { fetchURL, browserFetch, smartFetch, buildDuckDuckGoURL };
