'use strict';

/**
 * studyPlanGenerator.js
 *
 * Generates a time-boxed, personalized study plan from ranked resources.
 *
 * The plan distributes the student's available time budget across
 * the recommended resources in a sensible learning sequence,
 * and produces actionable tips based on their goal.
 */

/**
 * @typedef {Object} StudySlot
 * @property {number}  slotNumber
 * @property {string}  activity       - e.g. 'Watch', 'Read', 'Study', 'Review'
 * @property {string}  title
 * @property {string}  url
 * @property {string}  source
 * @property {string}  type
 * @property {number}  allocatedMinutes
 * @property {string}  tip            - What to focus on during this slot
 */

/**
 * @typedef {Object} StudyPlan
 * @property {number}      totalMinutes
 * @property {number}      allocatedMinutes
 * @property {number}      bufferMinutes   - Unallocated time (for breaks / review)
 * @property {StudySlot[]} slots
 * @property {string[]}    generalTips
 * @property {string}      summary         - One-line plan description
 */

// Verb to use for each resource type
const ACTIVITY_VERB = {
  video:     'Watch',
  course:    'Study',
  article:   'Read',
  reference: 'Review',
};

// Focus tips per goal type and slot position
const FOCUS_TIPS = {
  'basics': [
    'Take notes on new concepts and definitions.',
    'Pause and summarise each section in your own words.',
    'Highlight any terms you do not fully understand yet.',
    'Try to connect this to things you already know.',
    'Read actively — ask "why?" as you go.',
  ],
  'exam-prep': [
    'Focus on worked examples and problem-solving techniques.',
    'Note any formula derivations or proof steps.',
    'Mark any question types you have not seen before.',
    'Pay attention to common exam mistakes mentioned.',
    'After watching, try solving one problem from memory.',
  ],
  'quick-revision': [
    'Skim headings and highlighted sections first.',
    'Focus only on areas you are least confident about.',
    'Make a brief bullet-point list of key facts.',
    'Skip examples you already understand — save time.',
    'Check your recall: can you summarise this in 2 sentences?',
  ],
};

/**
 * Compute the ideal time allocation for a resource given constraints.
 * Never allocates more than the resource's estimated time,
 * and never more than 40% of the total budget for a single slot.
 *
 * @param {import('./resourceRanker').RankedResource} resource
 * @param {number} remainingMinutes
 * @param {number} totalMinutes
 * @returns {number}
 */
function allocateTime(resource, remainingMinutes, totalMinutes) {
  const maxSlotFraction = Math.floor(totalMinutes * 0.4);
  const ideal  = resource.estimatedMinutes;
  const capped = Math.min(ideal, maxSlotFraction, remainingMinutes);
  return Math.max(capped, 5); // minimum 5-minute slot
}

/**
 * Build a study tip for a specific slot based on goal type and slot index.
 */
function buildSlotTip(goalType, index) {
  const tips = FOCUS_TIPS[goalType] ?? FOCUS_TIPS['basics'];
  return tips[index % tips.length];
}

/**
 * General study tips based on goal type.
 */
function buildGeneralTips(goal) {
  const base = [
    `Set a timer for ${goal.availableMinutes} minutes before you start.`,
    'Keep a notepad beside you — physical writing improves retention.',
    'Take a 5-minute break every 25 minutes (Pomodoro technique).',
  ];

  const goalTips = {
    'basics': [
      'Start from the first resource and work through in order.',
      "Don't skip ahead — each concept builds on the last.",
    ],
    'exam-prep': [
      'After each resource, test yourself with 2–3 practice questions.',
      'Focus on understanding the method, not just memorising answers.',
    ],
    'quick-revision': [
      'Prioritise your weakest areas first.',
      'Use the Reference resource last as a quick checklist.',
    ],
  }[goal.goalType] ?? [];

  return [...base, ...goalTips];
}

/**
 * Generate a time-boxed study plan from ranked resources and a study goal.
 *
 * @param {import('./resourceRanker').RankedResource[]} rankedResources
 * @param {import('./goalParser').StudyGoal} goal
 * @returns {StudyPlan}
 */
function generateStudyPlan(rankedResources, goal) {
  const { availableMinutes, goalType } = goal;
  // Reserve 10% of time as buffer (minimum 5 min, maximum 15 min)
  const buffer  = Math.min(Math.max(Math.floor(availableMinutes * 0.1), 5), 15);
  let remaining = availableMinutes - buffer;

  const slots = [];

  for (let i = 0; i < rankedResources.length && remaining > 5; i++) {
    const resource = rankedResources[i];
    const allocated = allocateTime(resource, remaining, availableMinutes);

    slots.push({
      slotNumber:       i + 1,
      activity:         ACTIVITY_VERB[resource.type] ?? 'Study',
      title:            resource.title,
      url:              resource.url,
      source:           resource.source,
      type:             resource.type,
      allocatedMinutes: allocated,
      tip:              buildSlotTip(goalType, i),
    });

    remaining -= allocated;
  }

  const actuallyAllocated = slots.reduce((sum, s) => sum + s.allocatedMinutes, 0);
  const actualBuffer      = availableMinutes - actuallyAllocated;

  // Build a one-line summary
  const resourceCount = slots.length;
  const summary = `${resourceCount} resource${resourceCount !== 1 ? 's' : ''} · ${actuallyAllocated} min study + ${actualBuffer} min buffer`;

  return {
    totalMinutes:     availableMinutes,
    allocatedMinutes: actuallyAllocated,
    bufferMinutes:    actualBuffer,
    slots,
    generalTips:      buildGeneralTips(goal),
    summary,
  };
}

module.exports = { generateStudyPlan };
