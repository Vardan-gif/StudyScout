'use strict';

/**
 * resourceExtractor.js
 *
 * Normalizes raw text from webcmd fetch results into structured Resource objects.
 *
 * The input is unstructured text (article extraction from DuckDuckGo results,
 * YouTube search pages, Khan Academy, Wikipedia, etc.).
 * The extractor uses pattern matching to pull meaningful resource candidates.
 */

/**
 * @typedef {Object} Resource
 * @property {string}   url              - The resource URL
 * @property {string}   title            - Resource title
 * @property {string}   summary          - Short description or snippet
 * @property {string}   type             - 'video' | 'article' | 'course' | 'reference'
 * @property {number}   estimatedMinutes - Rough time estimate to consume the resource
 * @property {string}   source           - Detected source domain label
 * @property {string}   fetchMode        - 'fetch' | 'browser' (how webcmd retrieved it)
 * @property {string}   searchQuery      - The original query that produced this result
 */

// URL regex — captures http(s) links from extracted text
const URL_RE = /https?:\/\/[^\s"'<>)(\]]+/g;

/**
 * DuckDuckGo wraps real URLs as redirect links:
 *   https://duckduckgo.com/l/?uddg=https%3A%2F%2Fwww.example.com%2Fpath&rut=...
 *
 * This function decodes them into the real destination URL.
 * Returns the original URL unchanged if it's not a DDG redirect.
 */
function decodeDDGRedirect(url) {
  try {
    if (!url.includes('duckduckgo.com/l/')) return url;
    const parsed = new URL(url);
    const uddg   = parsed.searchParams.get('uddg');
    if (uddg) return decodeURIComponent(uddg);
  } catch { /* fall through */ }
  return url;
}


/**
 * Infer resource type from URL and surrounding text.
 */
function inferType(url, text) {
  if (url.includes('youtube.com') || url.includes('youtu.be')) return 'video';
  if (url.includes('khanacademy.org')) return 'course';
  if (url.includes('wikipedia.org')) return 'reference';
  if (/lecture|course|mooc|coursera|edx|udemy|mit\.edu/i.test(url)) return 'course';
  return 'article';
}

/**
 * Infer a human-readable source label from a URL.
 */
function inferSource(url) {
  try {
    const hostname = new URL(url).hostname.replace('www.', '');
    const SOURCE_MAP = {
      'youtube.com':           'YouTube',
      'youtu.be':              'YouTube',
      'khanacademy.org':       'Khan Academy',
      'wikipedia.org':         'Wikipedia',
      'mit.edu':               'MIT OpenCourseWare',
      'ocw.mit.edu':           'MIT OpenCourseWare',
      'coursera.org':          'Coursera',
      'edx.org':               'edX',
      'physicsclassroom.com':  'Physics Classroom',
      'hyperphysics.phy-astr.gsu.edu': 'HyperPhysics',
      'electronics-tutorials.ws': 'Electronics Tutorials',
      'geeksforgeeks.org':     'GeeksForGeeks',
      'libretexts.org':        'LibreTexts',
      'phys.libretexts.org':   'LibreTexts Physics',
      'chem.libretexts.org':   'LibreTexts Chemistry',
      'math.libretexts.org':   'LibreTexts Math',
      'allaboutcircuits.com':  'All About Circuits',
      'electricaltechnology.org': 'Electrical Technology',
      'physicsandelectronics.com': 'Physics & Electronics',
      'lecturescribe.io':      'LectureScribe',
      'brilliant.org':         'Brilliant',
      'studysmarter.co.uk':    'StudySmarter',
      'savemyexams.com':       'Save My Exams',
      'chegg.com':             'Chegg',
      'quora.com':             'Quora',
      'stackexchange.com':     'Stack Exchange',
      'scholar.google.com':    'Google Scholar',
    };
    return SOURCE_MAP[hostname] ?? hostname;
  } catch {
    return 'Unknown';
  }
}


/**
 * Estimate time to consume resource based on type.
 * These are intentionally conservative for study planning.
 */
function estimateMinutes(type, text) {
  // Try to find timestamps in video results (e.g. "12:34" or "12 minutes")
  const timestampMatch = text.match(/(\d{1,2}):(\d{2})(?!\d)/);
  if (timestampMatch && type === 'video') {
    const mins = parseInt(timestampMatch[1], 10);
    const secs = parseInt(timestampMatch[2], 10);
    return Math.max(1, mins + Math.round(secs / 60));
  }

  const minuteMatch = text.match(/(\d+)\s*min/i);
  if (minuteMatch) return Math.min(parseInt(minuteMatch[1], 10), 120);

  // Defaults by type
  return { video: 15, course: 30, article: 10, reference: 8 }[type] ?? 12;
}

/**
 * Extract a short summary from text around a URL.
 * Takes up to 200 chars following the URL in the raw text.
 */
function extractSummary(rawText, url) {
  const idx = rawText.indexOf(url);
  if (idx === -1) return '';
  const snippet = rawText.slice(idx + url.length, idx + url.length + 300)
    .replace(/\s+/g, ' ')
    .trim()
    .replace(/^[^a-zA-Z0-9]+/, ''); // strip leading punctuation
  return snippet.slice(0, 200);
}

/**
 * Extract a plausible title from raw text near a URL.
 * DuckDuckGo HTML results place the link title before the URL.
 */
function extractTitle(rawText, url, source) {
  const idx = rawText.indexOf(url);
  if (idx === -1) return `${source} resource`;
  const before = rawText.slice(Math.max(0, idx - 300), idx);
  const lines = before.split('\n').map(l => l.trim()).filter(Boolean);
  // Take the last non-empty line before the URL as the title candidate
  const candidate = lines[lines.length - 1] ?? '';
  if (candidate.length > 5 && candidate.length < 150) return candidate;
  return `${source} resource`;
}

/**
 * Filter out URLs that are not useful educational resources.
 * Called AFTER DDG redirect decoding, so urls here are real destinations.
 */
function isUsefulURL(url) {
  const SKIP_PATTERNS = [
    /duckduckgo\.com/,
    /external-content\.duckduckgo\.com/,
    /google\.com\/(?!scholar)/,
    /bing\.com/,
    /twitter\.com/, /x\.com/,
    /facebook\.com/,
    /instagram\.com/,
    /t\.co\//,
    /bit\.ly/,
    /amazon\.com/,
    /reddit\.com/,
    /\/ads\//,
    /\/cdn-cgi\//,
    /\/static\//,
    /\/assets\//,
    /\.png$/, /\.jpg$/, /\.jpeg$/, /\.gif$/, /\.svg$/, /\.ico$/, /\.webp$/,
    /\.css$/, /\.js$/,
    /javascript:/,
    /^https?:\/\/[^/]+\/?$/, // bare homepage with no path (too generic)
  ];
  return !SKIP_PATTERNS.some(re => re.test(url));
}

/**
 * Deduplicate resources.
 * - Primary key: hostname + path
 * - Secondary key: title (catches same article served at multiple URLs)
 * Also strips any leaked DDG redirect links from summary fields.
 */
function deduplicate(resources) {
  const seenPaths  = new Set();
  const seenTitles = new Set();

  return resources
    .map(r => {
      // Clean the summary: strip DDG redirect snippets that leaked in
      const cleanSummary = (r.summary ?? '')
        .replace(/!https?:\/\/duckduckgo\.com\/l\/[^\s]*/g, '')
        .replace(/https?:\/\/duckduckgo\.com\/l\/[^\s]*/g, '')
        .trim();
      return { ...r, summary: cleanSummary };
    })
    .filter(r => {
      try {
        const u    = new URL(r.url);
        const key  = u.hostname + u.pathname;
        const tkey = (r.title ?? '').toLowerCase().slice(0, 80);

        if (seenPaths.has(key))  return false;
        if (tkey.length > 10 && seenTitles.has(tkey)) return false;

        seenPaths.add(key);
        if (tkey.length > 10) seenTitles.add(tkey);
        return true;
      } catch {
        return false;
      }
    });
}

/**
 * Extract title from the markdown text that webcmd returns for DDG results.
 *
 * webcmd's extraction converts DDG HTML into markdown where each result looks like:
 *   ## [Title text](https://duckduckgo.com/l/?uddg=https%3A%2F%2F...)
 *   [Description snippet](...)
 *
 * This function finds the heading that precedes a given URL in the markdown.
 */
function extractTitleFromMarkdown(rawText, originalUrl, decodedUrl, source) {
  // Look for ## [Title](url-containing-this-domain)
  const lines = rawText.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    // Match markdown heading lines: ## [Title Text](url)
    const headingMatch = line.match(/^#+\s+\[([^\]]+)\]\(/);
    if (headingMatch) {
      // Check if the next 3 lines reference our URL's domain
      const domain = (() => {
        try { return new URL(decodedUrl).hostname.replace('www.', ''); } catch { return ''; }
      })();
      const context = lines.slice(i, i + 4).join(' ');
      if (domain && context.includes(domain)) {
        const candidate = headingMatch[1].trim();
        if (candidate.length > 3) return candidate;
      }
    }
  }
  // Fallback to old method
  return extractTitle(rawText, originalUrl, source);
}

/**
 * Extract snippet/summary following a URL reference in markdown.
 * For DDG markdown, the description follows the favicon+domain line.
 */
function extractSummaryFromMarkdown(rawText, originalUrl, decodedUrl) {
  const lines = rawText.split('\n');
  const domain = (() => {
    try { return new URL(decodedUrl).hostname.replace('www.', ''); } catch { return ''; }
  })();

  for (let i = 0; i < lines.length; i++) {
    if (domain && lines[i].includes(domain)) {
      // The description usually appears in the next 1-3 lines
      for (let j = i + 1; j < Math.min(i + 4, lines.length); j++) {
        const candidate = lines[j]
          .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // strip markdown links
          .replace(/[[\]()]/g, '')
          .trim();
        if (candidate.length > 30) return candidate.slice(0, 200);
      }
    }
  }
  return extractSummary(rawText, originalUrl);
}

/**
 * Extract Resource objects from a raw FetchResult.
 *
 * @param {import('./webcmdBrowser').FetchResult} fetchResult
 * @param {string} searchQuery - The query that produced this result
 * @returns {Resource[]}
 */
function extractResources(fetchResult, searchQuery) {
  if (!fetchResult.success || !fetchResult.text) return [];

  const rawText = fetchResult.text;

  // Extract all URLs from the text, then decode DDG redirects
  const rawUrls = [...new Set((rawText.match(URL_RE) ?? []))];
  const urlPairs = rawUrls.map(raw => ({
    original: raw,
    decoded:  decodeDDGRedirect(raw),
  }));

  const resources = urlPairs
    .filter(({ decoded }) => isUsefulURL(decoded))
    .slice(0, 25) // cap per-result processing
    .map(({ original, decoded }) => {
      const type    = inferType(decoded, rawText);
      const source  = inferSource(decoded);
      const title   = extractTitleFromMarkdown(rawText, original, decoded, source);
      const summary = extractSummaryFromMarkdown(rawText, original, decoded);
      const estimatedMinutes = estimateMinutes(type, rawText.slice(
        Math.max(0, rawText.indexOf(original) - 100),
        rawText.indexOf(original) + 400
      ));

      /** @type {Resource} */
      return {
        url: decoded,        // ← use the real URL, not the DDG redirect
        title,
        summary,
        type,
        source,
        estimatedMinutes,
        fetchMode: fetchResult.mode,
        searchQuery,
      };
    });

  return deduplicate(resources);
}

/**
 * Merge and deduplicate resources from multiple fetch results.
 *
 * @param {Array<{ fetchResult: import('./webcmdBrowser').FetchResult, query: string }>} results
 * @returns {Resource[]}
 */
function mergeResources(results) {
  const all = results.flatMap(({ fetchResult, query }) =>
    extractResources(fetchResult, query)
  );
  return deduplicate(all);
}

module.exports = { extractResources, mergeResources };
