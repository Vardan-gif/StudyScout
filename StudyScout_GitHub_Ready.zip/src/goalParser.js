'use strict';

/**
 * goalParser.js
 *
 * Parses raw student input from the request body into a structured StudyGoal
 * object. This is a pure function with no side effects.
 */

/**
 * @typedef {Object} StudyGoal
 * @property {string}   topic            - The raw topic string from the student
 * @property {string}   level            - One of: 'beginner' | 'intermediate' | 'advanced'
 * @property {number}   availableMinutes - Time budget in minutes
 * @property {string}   goalType         - One of: 'basics' | 'exam-prep' | 'quick-revision'
 * @property {string[]} keywords         - Derived keywords for search expansion
 * @property {string}   levelLabel       - Human-readable level label
 * @property {string}   goalLabel        - Human-readable goal label
 * @property {string[]} practiceSignals  - Explicit user intent signals found in topic text.
 *                                        e.g. ['numericals', 'video', 'beginner'].
 *                                        Only set when user explicitly states the need.
 */

/**
 * Detect explicit learning intent signals stated in the raw topic text.
 * Only returns signals that are directly stated — never inferred/fabricated.
 *
 * @param {string} raw
 * @returns {string[]}
 */
function detectPracticeSignals(raw) {
  const t = raw.toLowerCase();
  const signals = [];
  if (/numerical|numerics|solved\s+problem|practice\s+problem|worked\s+example/i.test(t)) signals.push('numericals');
  if (/video|watch|youtube|animation|visual|diagram/i.test(t))                             signals.push('video');
  if (/beginner|basic|simple|easy|start\s+from\s+scratch/i.test(t))                       signals.push('beginner');
  if (/revision|revise|quick|cheat\s+sheet|summary|recap/i.test(t))                       signals.push('revision');
  if (/exam|test|question|mcq|quiz|past\s+paper/i.test(t))                                signals.push('exam');
  if (/note|notes|pdf|article|read/i.test(t))                                              signals.push('notes');
  if (/deep|thorough|detailed|in.depth|comprehensive/i.test(t))                            signals.push('deep');
  return signals;
}

const LEVEL_MAP = {
  beginner:     { label: 'Beginner / High school',   weight: 0 },
  intermediate: { label: 'Undergraduate / First-year', weight: 1 },
  advanced:     { label: 'Advanced / Postgraduate',   weight: 2 },
};

const GOAL_MAP = {
  'basics':         { label: 'Understand from basics',  depthBias: 'conceptual' },
  'exam-prep':      { label: 'Exam preparation',        depthBias: 'applied'    },
  'quick-revision': { label: 'Quick revision',          depthBias: 'summary'    },
};

/**
 * Extract simple keywords from a topic string.
 * Strips common filler words so search queries are tighter.
 */
function deriveKeywords(topic) {
  const STOP_WORDS = new Set([
    'a', 'an', 'the', 'and', 'or', 'for', 'in', 'on', 'at', 'to', 'of',
    'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had',
    'do', 'does', 'did', 'will', 'would', 'could', 'should', 'may', 'might',
    'about', 'how', 'what', 'why', 'when', 'where', 'which', 'who', 'teach',
    'me', 'learn', 'study', 'explain', 'understand', 'help', 'need',
  ]);

  return topic
    .toLowerCase()
    .replace(/[^a-z0-9\s'-]/g, ' ')
    .split(/\s+/)
    .filter(w => w.length > 1 && !STOP_WORDS.has(w));
}

/**
 * Parse raw request body fields into a validated StudyGoal.
 *
 * @param {Object} body  - Express request body
 * @param {string} body.topic
 * @param {string} [body.level]
 * @param {number|string} [body.availableMinutes]
 * @param {string} [body.goalType]
 * @returns {StudyGoal}
 * @throws {Error} if required fields are missing or invalid
 */
function parseGoal(body) {
  const { topic, level, availableMinutes, goalType } = body;

  if (!topic || typeof topic !== 'string' || topic.trim().length === 0) {
    throw new Error('A topic is required.');
  }

  const cleanTopic = topic.trim();

  const resolvedLevel = LEVEL_MAP[level] ? level : 'intermediate';
  const resolvedGoal  = GOAL_MAP[goalType] ? goalType : 'exam-prep';

  const minutes = parseInt(availableMinutes, 10);
  const resolvedMinutes = (!isNaN(minutes) && minutes > 0 && minutes <= 480)
    ? minutes
    : 60;

  const keywords = deriveKeywords(cleanTopic);
  const practiceSignals = detectPracticeSignals(cleanTopic);

  return {
    topic:            cleanTopic,
    level:            resolvedLevel,
    availableMinutes: resolvedMinutes,
    goalType:         resolvedGoal,
    keywords,
    practiceSignals,
    levelLabel:       LEVEL_MAP[resolvedLevel].label,
    goalLabel:        GOAL_MAP[resolvedGoal].label,
    depthBias:        GOAL_MAP[resolvedGoal].depthBias,
  };
}

module.exports = { parseGoal };
