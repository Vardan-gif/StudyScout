'use strict';

/**
 * syllabusParser.js
 *
 * Extracts topic/unit structure from a syllabus PDF.
 *
 * Uses pdf-parse (pure Node, no external API).
 * Falls back gracefully if the PDF is image-based or unreadable.
 *
 * Returns an array of topic strings the student can select.
 */

let pdfParse;
try {
  pdfParse = require('pdf-parse');
} catch {
  pdfParse = null;
}

/**
 * Extract topics from a PDF buffer.
 *
 * @param {Buffer} buffer - Raw PDF file buffer
 * @returns {Promise<{ topics: string[], rawText: string, warning?: string }>}
 */
async function extractTopicsFromPDF(buffer) {
  if (!pdfParse) {
    return {
      topics: [],
      rawText: '',
      warning: 'pdf-parse module is not installed. Run: npm install pdf-parse',
    };
  }

  let data;
  try {
    data = await pdfParse(buffer, { max: 10 }); // parse first 10 pages max
  } catch (err) {
    return {
      topics: [],
      rawText: '',
      warning: `PDF parsing failed: ${err.message}`,
    };
  }

  const rawText = data.text || '';

  if (rawText.trim().length < 50) {
    return {
      topics: [],
      rawText,
      warning: 'PDF appears to be image-based or has no extractable text. Enter topics manually.',
    };
  }

  const topics = detectTopics(rawText);

  if (topics.length === 0) {
    // Fallback: return first meaningful lines
    const fallback = rawText
      .split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 8 && l.length < 120 && !/^\s*\d+\s*$/.test(l))
      .slice(0, 20);
    return { topics: fallback, rawText, warning: 'Could not detect unit structure — showing all text lines.' };
  }

  return { topics, rawText };
}

/**
 * Detect structured topics from raw text using pattern matching.
 *
 * Looks for:
 *  - Numbered items: 1. Title, 1) Title, UNIT 1, Unit-1
 *  - Bulleted items: • Title, - Title
 *  - UPPERCASE headings
 *  - Lines starting with Chapter / Module / Topic
 */
function detectTopics(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const topics = [];

  // Patterns that indicate a topic line
  const TOPIC_PATTERNS = [
    /^(unit|chapter|module|topic|section)\s*[-:]?\s*\d+\s*[-:]?\s*/i,
    /^\d+[.)]\s+[A-Z]/,
    /^[•\-–]\s+\S.{4,}/,
    /^[IVXLC]+\.\s+[A-Z]/,
  ];

  // Patterns that indicate noise lines to skip
  const SKIP_PATTERNS = [
    /^page\s*\d+/i,
    /^(www\.|http|@|tel:|email)/i,
    /^\s*\d+\s*$/,           // just a number
    /^[\W_]+$/,              // all punctuation/spaces
  ];

  for (const line of lines) {
    if (SKIP_PATTERNS.some(re => re.test(line))) continue;
    if (line.length < 4 || line.length > 120) continue;

    if (TOPIC_PATTERNS.some(re => re.test(line))) {
      // Clean the line: strip leading bullet/number
      const cleaned = line
        .replace(/^(unit|chapter|module|topic|section)\s*[-:]?\s*\d+\s*[-:]?\s*/i, '')
        .replace(/^\d+[.)]\s+/, '')
        .replace(/^[•\-–]\s+/, '')
        .replace(/^[IVXLC]+\.\s+/, '')
        .trim();

      if (cleaned.length > 3) topics.push(cleaned);
    }
  }

  // Deduplicate
  return [...new Set(topics)].slice(0, 40);
}

module.exports = { extractTopicsFromPDF };

// ── Extended export: intelligent document analysis ─────────────────────────────
// Delegates to documentClassifier.js — zero duplication.
// extractTopicsFromPDF above is preserved unchanged for backward compat.
const { analyzeDocument } = require('./documentClassifier');

/**
 * Analyze a PDF and return a full DocumentAnalysis object.
 * Use this instead of extractTopicsFromPDF for the new upload endpoint.
 *
 * @param {Buffer} buffer
 * @param {string} filename
 * @returns {Promise<import('./documentClassifier').DocumentAnalysis>}
 */
async function parseAndClassify(buffer, filename) {
  return analyzeDocument(buffer, filename);
}

module.exports.parseAndClassify = parseAndClassify;
