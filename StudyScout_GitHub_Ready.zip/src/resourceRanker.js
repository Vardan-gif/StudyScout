'use strict';

/**
 * resourceRanker.js
 *
 * Scores and ranks Resource objects against a StudyGoal.
 *
 * Each resource receives a score (0–100) and a list of human-readable
 * reasons explaining why it was selected or ranked where it was.
 *
 * Scoring is entirely rule-based. Dropping in an LLM reranker later
 * only requires replacing the `scoreResource` function below.
 */

/**
 * @typedef {Object} RankedResource
 * @property {string}   url
 * @property {string}   title
 * @property {string}   summary
 * @property {string}   type
 * @property {string}   source
 * @property {number}   estimatedMinutes
 * @property {string}   fetchMode
 * @property {string}   searchQuery
 * @property {number}   score         - 0–100
 * @property {string[]} reasons       - Why this resource was selected/ranked
 * @property {string}   badge         - Short label: 'Best Match' | 'Quick Watch' | etc.
 */

// Source quality weights (higher = more trustworthy for learning)
const SOURCE_WEIGHTS = {
  'YouTube':                 20,
  'Khan Academy':            25,
  'Wikipedia':               15,
  'MIT OpenCourseWare':      25,
  'Coursera':                22,
  'edX':                     22,
  'Physics Classroom':       20,
  'HyperPhysics':            18,
  'Electronics Tutorials':   20,
  'GeeksForGeeks':           18,
  'LibreTexts':              22,
  'LibreTexts Physics':      22,
  'LibreTexts Chemistry':    22,
  'LibreTexts Math':         22,
  'All About Circuits':      20,
  'Electrical Technology':   17,
  'Physics & Electronics':   17,
  'LectureScribe':           16,
  'Brilliant':               20,
  'StudySmarter':            16,
  'Save My Exams':           18,
  'Google Scholar':          15,
};

// Type weights per goal type
const TYPE_GOAL_WEIGHTS = {
  'basics': {
    video:     25,
    course:    20,
    article:   15,
    reference: 10,
  },
  'exam-prep': {
    video:     20,
    course:    25,
    article:   20,
    reference: 10,
  },
  'quick-revision': {
    video:     15,
    course:    10,
    article:   20,
    reference: 25,
  },
};

/**
 * Score a single resource against the study goal.
 *
 * @param {import('./resourceExtractor').Resource} resource
 * @param {import('./goalParser').StudyGoal} goal
 * @returns {{ score: number, reasons: string[] }}
 */
function scoreResource(resource, goal) {
  let score = 0;
  const reasons = [];

  // 1. Source reputation
  const sourceScore = SOURCE_WEIGHTS[resource.source] ?? 10;
  score += sourceScore;
  if (sourceScore >= 20) {
    reasons.push(`Trusted educational source (${resource.source})`);
  }

  // 2. Type alignment with goal
  const typeWeights = TYPE_GOAL_WEIGHTS[goal.goalType] ?? TYPE_GOAL_WEIGHTS['basics'];
  const typeScore   = typeWeights[resource.type] ?? 10;
  score += typeScore;
  reasons.push(`${resource.type.charAt(0).toUpperCase() + resource.type.slice(1)} format suits ${goal.goalLabel.toLowerCase()}`);

  // 3. Keyword match in title/summary
  const topicLower   = goal.topic.toLowerCase();
  const titleLower   = resource.title.toLowerCase();
  const summaryLower = resource.summary.toLowerCase();
  const keywordHits  = goal.keywords.filter(kw =>
    titleLower.includes(kw) || summaryLower.includes(kw)
  );

  const keywordScore = Math.min(keywordHits.length * 8, 24);
  score += keywordScore;
  if (keywordHits.length > 0) {
    reasons.push(`Matches key terms: ${keywordHits.slice(0, 3).join(', ')}`);
  }

  // Topic name in title is a strong positive
  if (titleLower.includes(topicLower) || topicLower.split(' ').some(w => w.length > 3 && titleLower.includes(w))) {
    score += 10;
    reasons.push('Topic directly mentioned in title');
  }

  // 4. Time fit — does the resource fit within the available time?
  const timeRatio = resource.estimatedMinutes / goal.availableMinutes;
  if (timeRatio <= 0.4) {
    score += 10;
    reasons.push(`Short enough to fit comfortably (≈${resource.estimatedMinutes} min)`);
  } else if (timeRatio <= 0.7) {
    score += 6;
  } else if (timeRatio > 1.0) {
    score -= 10;
    reasons.push(`May be too long for your ${goal.availableMinutes}-min budget`);
  }

  // 5. Level match heuristics
  const levelKeywords = {
    beginner:     ['beginner', 'basic', 'introduction', 'simple', 'easy'],
    intermediate: ['engineering', 'undergraduate', 'college', 'tutorial'],
    advanced:     ['advanced', 'graduate', 'research', 'lecture', 'proof'],
  }[goal.level] ?? [];

  const levelHits = levelKeywords.filter(kw =>
    titleLower.includes(kw) || summaryLower.includes(kw)
  );
  if (levelHits.length > 0) {
    score += 8;
    reasons.push(`Content level matches your profile (${goal.levelLabel})`);
  }

  // 6. Practice signals — only boost when user explicitly stated the need
  //    AND the resource shows actual evidence in its title/summary.
  const signals = goal.practiceSignals ?? [];

  if (signals.includes('numericals')) {
    if (/numerical|solved|example|problem|workout|exercise/i.test(titleLower + ' ' + summaryLower)) {
      score += 12;
      reasons.push('Contains solved problems / numericals (as you requested)');
    }
  }
  if (signals.includes('video') && resource.type === 'video') {
    score += 10;
    reasons.push('Video format — matches your preference');
  }
  if (signals.includes('beginner')) {
    if (/beginner|basic|introduction|simple|easy/i.test(titleLower + ' ' + summaryLower)) {
      score += 8;
      reasons.push('Beginner-friendly (as you requested)');
    }
  }
  if (signals.includes('exam')) {
    if (/exam|question|test|quiz|mcq|past\s+paper/i.test(titleLower + ' ' + summaryLower)) {
      score += 8;
      reasons.push('Includes exam-style questions');
    }
    // Additional: resources with "formula" or "derivation" help exam prep
    if (/formula|derivation|proof/i.test(titleLower + ' ' + summaryLower)) {
      score += 4;
      reasons.push('Contains formula / derivation references (exam-relevant)');
    }
  }
  if (signals.includes('revision') && (resource.type === 'reference' || resource.type === 'article')) {
    score += 6;
    reasons.push('Article/notes format — good for revision');
  }
  if (signals.includes('notes') && (resource.type === 'article' || resource.type === 'reference')) {
    score += 6;
    reasons.push('Article/notes format — matches your request');
  }

  // 7. Concept depth & visual explanation heuristics
  //    Boost resources that appear to offer deeper theory or visual support
  if (/diagram|visual|illustration|schematic|figure/i.test(titleLower + ' ' + summaryLower)) {
    score += 5;
    reasons.push('Includes diagrams or visual explanations');
  }
  if (/concept|derivation|theory|proof/i.test(titleLower + ' ' + summaryLower)) {
    score += 4;
    reasons.push('Conceptual depth — strong on theory');
  }
  if (/video/i.test(titleLower + ' ' + summaryLower) && resource.type === 'video') {
    // Online videos often have visual explanations
    score += 3;
    reasons.push('Video format with visual explanation');
  }

  // 7. Fetch mode bonus — browser mode means we got real rendered content
  if (resource.fetchMode === 'browser') {
    score += 3;
    reasons.push('Retrieved via Webcmd browser session (richer content)');
  }

  return { score: Math.min(Math.max(Math.round(score), 0), 100), reasons };
}

/**
 * Assign a short badge label based on score and resource properties.
 */
function assignBadge(resource, rank) {
  if (rank === 0) return 'Best Match';
  if (resource.type === 'video' && resource.estimatedMinutes <= 15) return 'Quick Watch';
  if (resource.source === 'Khan Academy') return 'Structured Course';
  if (resource.source === 'Wikipedia') return 'Reference';
  if (resource.type === 'course') return 'In-Depth Course';
  if (resource.estimatedMinutes <= 8) return 'Fast Read';
  return 'Recommended';
}

/**
 * Rank resources against a study goal.
 *
 * @param {import('./resourceExtractor').Resource[]} resources
 * @param {import('./goalParser').StudyGoal} goal
 * @param {number} [topN=6] - Maximum number of resources to return
 * @returns {RankedResource[]}
 */
function rankResources(resources, goal, topN = 6) {
  if (resources.length === 0) return [];

  const scored = resources.map(resource => {
    const { score, reasons } = scoreResource(resource, goal);
    return { ...resource, score, reasons };
  });

  // Sort descending by score, then by estimatedMinutes (prefer shorter first on tie)
  scored.sort((a, b) => b.score - a.score || a.estimatedMinutes - b.estimatedMinutes);

  const top = scored.slice(0, topN);

  return top.map((resource, idx) => ({
    ...resource,
    badge: assignBadge(resource, idx),
  }));
}

module.exports = { rankResources };
