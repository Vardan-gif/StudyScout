'use strict';

/**
 * documentClassifier.js
 *
 * Analyzes an academic PDF and produces a structured DocumentAnalysis object.
 *
 * ─── How it works ─────────────────────────────────────────────────────────────
 * This is a RULE-BASED classifier. No LLM is called here.
 *
 * 1. Parse PDF text (via pdf-parse, same dep as syllabusParser.js)
 * 2. Validate: min text length, check it is not image-only
 * 3. Score text against per-type keyword/pattern tables
 * 4. Choose type with highest score; compute confidence
 * 5. If isAcademic, extract structured content (units, topics, questions)
 * 6. Compose a research topic string automatically
 *
 * Returns a DocumentAnalysis object consumed by server.js and the frontend.
 * ──────────────────────────────────────────────────────────────────────────────
 */

let pdfParse;
try   { pdfParse = require('pdf-parse'); }
catch { pdfParse = null; }

// ── Document type constants ────────────────────────────────────────────────────
const DOCTYPE = {
  SYLLABUS:    'syllabus',
  LECTURE:     'lecture_notes',
  QUESTION:    'question_paper',
  RESEARCH:    'research_material',
  STUDY:       'study_material',
  INVALID:     'invalid',
};

// ── Human-readable labels ──────────────────────────────────────────────────────
const DOCTYPE_LABEL = {
  syllabus:          'Syllabus / Course Outline',
  lecture_notes:     'Lecture Notes / Study Material',
  question_paper:    'Question Paper / Exam Paper',
  research_material: 'Academic Reference / Research Material',
  study_material:    'Course / Study Material',
  invalid:           'Not Academic / Invalid',
};

// ── Scoring keyword tables ─────────────────────────────────────────────────────
// Each entry: { pattern: RegExp, weight: number }
// The classifier sums weights for each type and picks the highest.

const SIGNALS = {
  [DOCTYPE.SYLLABUS]: [
    { re: /\bunit\s*[-–:]?\s*\d+/i,               w: 3 },
    { re: /\bmodule\s*[-–:]?\s*\d+/i,              w: 3 },
    { re: /\blearning\s+objectives?\b/i,            w: 4 },
    { re: /\bcourse\s+(?:code|outline|structure)\b/i, w: 4 },
    { re: /\bsyllabus\b/i,                          w: 5 },
    { re: /\bscheme\s+of\s+(teaching|examination)\b/i, w: 5 },
    { re: /\bhours?\s+per\s+week\b/i,               w: 4 },
    { re: /\bcontact\s+hours?\b/i,                  w: 3 },
    { re: /\binternal\s+(marks?|assessment)\b/i,    w: 4 },
    { re: /\bsemester\b/i,                          w: 2 },
    { re: /\bprescribed\s+(?:text|books?)\b/i,      w: 4 },
    { re: /\breference\s+books?\b/i,                w: 2 },
    { re: /\bexamination\s+scheme\b/i,              w: 4 },
    { re: /\bcredits?\b/i,                          w: 2 },
    { re: /\bcourse\s+(?:code|title|name)\b/i,      w: 3 },
    { re: /\bsubject\s+code\b/i,                    w: 3 },
  ],

  [DOCTYPE.LECTURE]: [
    { re: /\bdefinition\b/i,                        w: 3 },
    { re: /\btheorem\b/i,                           w: 4 },
    { re: /\bproof\b/i,                             w: 3 },
    { re: /\bderivation\b/i,                        w: 4 },
    { re: /\bformula\b/i,                           w: 3 },
    { re: /\bexample\s*:/i,                         w: 3 },
    { re: /\bsolution\s*:/i,                        w: 3 },
    { re: /\bfig(?:ure)?\s*\d+/i,                  w: 3 },
    { re: /\bnote\s*:/i,                            w: 2 },
    { re: /\blecture\s+\d+\b/i,                     w: 5 },
    { re: /\btopic\s*:/i,                           w: 2 },
    { re: /\bwhere\b.{0,40}=.{0,20}(amp|volt|ohm|watt|farad|henry)/i, w: 3 },
    { re: /\bsubstitut(e|ing)\b/i,                  w: 2 },
    { re: /\bwe\s+(?:know|have|get|obtain)\b/i,     w: 2 },
  ],

  [DOCTYPE.QUESTION]: [
    { re: /\bq\s*\.\s*\d+\b/i,                     w: 4 },
    { re: /\battempt\s+(?:all|any)\b/i,             w: 5 },
    { re: /\btime\s+allowed?\s*:/i,                 w: 5 },
    { re: /\bmaximum\s+marks?\s*:/i,                w: 5 },
    { re: /\bsection\s+[a-z]\b/i,                   w: 3 },
    { re: /\banswer\s+(?:all|any)\s+(?:\d+|the)\b/i, w: 5 },
    { re: /\b\[\s*\d+\s+marks?\s*\]/i,             w: 4 },
    { re: /\b\(\s*\d+\s+marks?\s*\)/i,             w: 4 },
    { re: /\broll\s+(?:no|number)\b/i,              w: 4 },
    { re: /\bexamination\b/i,                       w: 2 },
    { re: /\bend\s+sem(?:ester)?\b/i,               w: 4 },
    { re: /\bmid\s+(?:term|sem)\b/i,                w: 4 },
    { re: /\bset\s*[-:]?\s*[a-d]\b/i,               w: 3 },
    { re: /\bpaper\s+setter\b/i,                    w: 5 },
    { re: /\binvigilator\b/i,                       w: 5 },
  ],

  [DOCTYPE.RESEARCH]: [
    { re: /\babstract\b/i,                          w: 5 },
    { re: /\bintroduction\b/i,                      w: 2 },
    { re: /\bmethodology\b/i,                       w: 5 },
    { re: /\bconclusion\b/i,                        w: 3 },
    { re: /\breferences?\b/i,                       w: 3 },
    { re: /\bbibliography\b/i,                      w: 4 },
    { re: /\bdoi\s*:/i,                             w: 5 },
    { re: /\bjournal\b/i,                           w: 4 },
    { re: /\bpublished\s+in\b/i,                    w: 3 },
    { re: /\bproposed\s+(?:method|approach|algorithm)\b/i, w: 4 },
    { re: /\bresults?\s+and\s+discussion\b/i,       w: 5 },
    { re: /\bliterature\s+review\b/i,               w: 5 },
    { re: /\bpeer.reviewed\b/i,                     w: 5 },
    { re: /\bISSN\b/,                               w: 5 },
    { re: /\bet\s+al\b/i,                           w: 4 },
  ],

  [DOCTYPE.STUDY]: [
    { re: /\bchapter\s+\d+\b/i,                     w: 3 },
    { re: /\bkey\s+(?:points?|concepts?|terms?)\b/i, w: 3 },
    { re: /\bsummary\b/i,                           w: 3 },
    { re: /\bexercises?\b/i,                        w: 3 },
    { re: /\bpractice\s+(?:problems?|questions?)\b/i, w: 4 },
    { re: /\bobjectives?\s*:/i,                     w: 2 },
    { re: /\bintroduction\b/i,                      w: 1 },
    { re: /\bsection\s+\d+\b/i,                     w: 2 },
    { re: /\breviewed?\s+by\b/i,                    w: 2 },
  ],
};

// Signals that strongly indicate NON-academic content
const REJECT_SIGNALS = [
  { re: /\binvoice\b/i,           w: 8 },
  { re: /\breceipt\b/i,           w: 7 },
  { re: /\bgst\s+(?:no|number)\b/i, w: 7 },
  { re: /\bamount\s+due\b/i,      w: 7 },
  { re: /\bpayment\s+(?:terms?|due)\b/i, w: 7 },
  { re: /\bquotation\s+no\b/i,   w: 7 },
  { re: /\bcurriculum\s+vitae\b/i, w: 7 },
  { re: /\bresume\b/i,            w: 5 },
  { re: /\bwork\s+experience\b/i, w: 5 },
  { re: /\bemployment\s+history\b/i, w: 6 },
  { re: /\bterms?\s+(?:and\s+conditions?|of\s+service)\b/i, w: 6 },
  { re: /\bprivacy\s+policy\b/i,  w: 6 },
  { re: /\badvertisement\b/i,     w: 5 },
  { re: /\bbuy\s+now\b/i,         w: 5 },
  { re: /\bfree\s+delivery\b/i,   w: 6 },
];

// Minimum text needed to classify (characters)
const MIN_TEXT_LEN = 80;
// Minimum academic score for isAcademic = true
const MIN_ACADEMIC_SCORE = 4;
// Confidence threshold below which we warn the user (low confidence)
const LOW_CONFIDENCE_THRESHOLD = 0.60;

// ── Entry point ────────────────────────────────────────────────────────────────

/**
 * Analyze a PDF buffer and return a complete DocumentAnalysis.
 *
 * @param {Buffer}  buffer    Raw PDF bytes
 * @param {string}  filename  Original filename (used as a signal source)
 * @returns {Promise<DocumentAnalysis>}
 */
async function analyzeDocument(buffer, filename = '') {
  // Step 1: Parse
  const { text, pageCount, parseError } = await parseText(buffer);

  if (parseError) {
    return invalidResult(`PDF could not be read: ${parseError}`, '', pageCount);
  }

  // Step 2: Validate text length
  if (text.trim().length < MIN_TEXT_LEN) {
    const reason = text.trim().length === 0
      ? 'This PDF appears to be image-based or has no extractable text. StudyScout cannot read it.'
      : 'This PDF contains very little text. It may be a scanned image or a nearly empty document.';
    return invalidResult(reason, text, pageCount);
  }

  // Step 3: Classify
  const { type, score, confidence, totalSignal } = classifyDocument(text, filename);

  // Step 4: Check rejection signals
  const rejectScore = scoreSignals(text, REJECT_SIGNALS);
  if (rejectScore >= 6) {
    return invalidResult(
      'This document does not appear to be academic study material. ' +
      'It looks like a business, legal, or personal document.',
      text, pageCount
    );
  }

  // Step 5: If academic score is too low, treat as invalid
  if (score < MIN_ACADEMIC_SCORE) {
    return invalidResult(
      'StudyScout could not find course topics, academic content, exam questions, or learning objectives in this document.',
      text, pageCount
    );
  }

  const isAcademic = true;
  const docTypeLabel = DOCTYPE_LABEL[type];

  // Step 6: Extract structure based on type
  const structure = extractStructure(text, filename, type);

  // Step 7: Compose research topic
  const composedTopic = composeResearchTopic(structure, type);

  // Step 8: Derive research hints
  const researchHints = buildResearchHints(type, structure);

  return {
    isAcademic,
    documentType: type,
    confidence,
    reason: describeClassification(type, structure),
    subject: structure.subject,
    units: structure.units,
    topics: structure.topics,
    questions: structure.questions,
    composedTopic,
    researchHints,
    rawText: text,
    pageCount,
    lowConfidence: confidence < LOW_CONFIDENCE_THRESHOLD,
    docTypeLabel,
  };
}

// ── PDF text extraction ────────────────────────────────────────────────────────

async function parseText(buffer) {
  if (!pdfParse) {
    return { text: '', pageCount: 0, parseError: 'pdf-parse module not installed. Run: npm install pdf-parse' };
  }
  try {
    const data = await pdfParse(buffer, { max: 15 });
    return { text: data.text || '', pageCount: data.numpages || 0, parseError: null };
  } catch (err) {
    return { text: '', pageCount: 0, parseError: err.message };
  }
}

// ── Classifier ────────────────────────────────────────────────────────────────

function scoreSignals(text, signals) {
  return signals.reduce((sum, { re, w }) => sum + (re.test(text) ? w : 0), 0);
}

function classifyDocument(text, filename) {
  const fnLower = filename.toLowerCase();

  // Filename bonus (weak signal — content takes priority)
  const filenameBonuses = {
    [DOCTYPE.SYLLABUS]:  /syllabus|course.outline|curriculum/.test(fnLower) ? 3 : 0,
    [DOCTYPE.LECTURE]:   /lecture|notes?|unit\d/.test(fnLower) ? 3 : 0,
    [DOCTYPE.QUESTION]:  /question.paper|exam.paper|qp_/.test(fnLower) ? 3 : 0,
    [DOCTYPE.RESEARCH]:  /research|paper|journal/.test(fnLower) ? 2 : 0,
    [DOCTYPE.STUDY]:     /study|material|chapter/.test(fnLower) ? 2 : 0,
  };

  let best = { type: DOCTYPE.STUDY, score: 0 };
  let totalSignal = 0;

  for (const [type, signals] of Object.entries(SIGNALS)) {
    const contentScore = scoreSignals(text, signals);
    const total = contentScore + (filenameBonuses[type] || 0);
    totalSignal += contentScore;
    if (total > best.score) {
      best = { type, score: total };
    }
  }

  // Confidence: winner's score relative to sum of all scores
  const allScores = Object.entries(SIGNALS).map(([t, sigs]) =>
    scoreSignals(text, sigs) + (filenameBonuses[t] || 0)
  );
  const scoreSum = allScores.reduce((a, b) => a + b, 0) || 1;
  const confidence = Math.min(0.98, best.score / scoreSum);

  return { type: best.type, score: best.score, confidence, totalSignal };
}

// ── Structure extraction (type-aware) ─────────────────────────────────────────

function extractStructure(text, filename, docType) {
  const subject   = extractSubject(text, filename);
  const units     = extractUnits(text);
  const topics    = extractTopics(text);
  const questions = docType === DOCTYPE.QUESTION ? extractQuestions(text) : [];

  return { subject, units, topics, questions };
}

/**
 * Try to identify a subject/course name from the document.
 * Looks for common heading patterns near the top of the document.
 */
function extractSubject(text, filename) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);

  // Strong patterns for a subject line
  const SUBJECT_PATTERNS = [
    /^(?:subject|course|paper)\s*[-:]\s*(.+)$/i,
    /^(?:b\.?tech|be|bsc|mtech|bca|mca)\s+[–-]\s*(.+)$/i,
  ];

  for (const line of lines.slice(0, 25)) {
    for (const re of SUBJECT_PATTERNS) {
      const m = line.match(re);
      if (m) return m[1].trim().slice(0, 120);
    }
  }

  // Fallback: longest ALL-CAPS or Title Case line near top, that is not a university name
  for (const line of lines.slice(0, 20)) {
    if (line.length > 8 && line.length < 120) {
      if (/^[A-Z][A-Za-z\s&,/()-]+$/.test(line) && !/university|institute|college|dept|department/i.test(line)) {
        return line.slice(0, 120);
      }
    }
  }

  // Last resort: derive from filename
  const base = filename.replace(/\.pdf$/i, '').replace(/[_-]/g, ' ').replace(/\s+/g, ' ').trim();
  return base.slice(0, 80) || 'Academic Document';
}

/**
 * Extract unit/module headings.
 */
function extractUnits(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const units = [];
  const UNIT_RE = /^(?:unit|module|chapter|section)\s*[-–:]?\s*\d+\s*[-–:]?\s*(.+)?$/i;

  for (const line of lines) {
    const m = line.match(UNIT_RE);
    if (m) {
      const label = (m[1] || '').trim();
      const entry = label.length > 2 ? label : line.trim();
      if (entry.length > 2 && entry.length < 120) {
        units.push(entry.slice(0, 100));
      }
    }
  }
  return [...new Set(units)].slice(0, 15);
}

/**
 * Extract topic lines — enhanced version of the syllabusParser's detectTopics.
 * Returns more content by including more patterns.
 */
function extractTopics(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const topics = [];

  const TOPIC_PATTERNS = [
    /^(unit|chapter|module|topic|section)\s*[-:]?\s*\d+\s*[-:]?\s*/i,
    /^\d+[.)] [A-Z]/,
    /^\d+\.\d+[.)]?\s+\S/,          // 1.1 Sub-topic
    /^[•●▪\-–]\s+\S.{3,}/,
    /^[IVXLC]+\.\s+[A-Z]/,
  ];

  const SKIP = [
    /^page\s*\d+/i,
    /^(www\.|http|@|tel:|email)/i,
    /^\s*\d+\s*$/,
    /^[\W_]+$/,
    /^(?:and|or|the|a|an)\s/i,
  ];

  for (const line of lines) {
    if (line.length < 4 || line.length > 140) continue;
    if (SKIP.some(re => re.test(line))) continue;

    if (TOPIC_PATTERNS.some(re => re.test(line))) {
      const cleaned = line
        .replace(/^(unit|chapter|module|topic|section)\s*[-:]?\s*\d+\s*[-:]?\s*/i, '')
        .replace(/^\d+\.\d+[.)]?\s+/, '')
        .replace(/^\d+[.)] /, '')
        .replace(/^[•●▪\-–]\s+/, '')
        .replace(/^[IVXLC]+\.\s+/, '')
        .trim();

      if (cleaned.length > 3) topics.push(cleaned.slice(0, 100));
    }
  }

  return [...new Set(topics)].slice(0, 60);
}

/**
 * Extract questions from a question paper.
 * Looks for numbered questions with marks annotations.
 */
function extractQuestions(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const questions = [];

  const Q_PATTERNS = [
    /^Q\s*\.?\s*\d+[a-z]?\s*[.)]\s*(.+)/i,
    /^\d+\s*[.)]\s*(?:Define|Explain|Derive|Find|Calculate|Prove|Draw|Write|Solve|Describe|Discuss|Compare)\b(.+)/i,
    /^\([a-z]\)\s*(.{10,})/i,
  ];

  for (const line of lines) {
    if (line.length < 10 || line.length > 300) continue;
    for (const re of Q_PATTERNS) {
      const m = line.match(re);
      if (m) {
        // Strip marks annotation
        const q = (m[1] || line).replace(/\[\s*\d+\s*marks?\s*\]/i, '').trim();
        if (q.length > 8) questions.push(q.slice(0, 160));
        break;
      }
    }
  }

  return [...new Set(questions)].slice(0, 30);
}

// ── Topic composition for research pipeline ────────────────────────────────────

/**
 * Compose a tight research topic string from the extracted structure.
 * This string flows directly into parseGoal() → conceptMapper → Webcmd.
 *
 * Strategy per document type:
 *  - SYLLABUS:   "[subject] — [top unit topics grouped]"
 *  - LECTURE:    "[subject] — detailed explanation and examples"
 *  - QUESTION:   "[subject] — exam preparation solved problems and practice questions for [topic cluster]"
 *  - RESEARCH:   "[subject] — understanding the core concepts"
 *  - STUDY:      "[subject] — [top topics]"
 */
function composeResearchTopic(structure, docType) {
  const { subject, units, topics, questions } = structure;

  // Pick the best "anchor" — prefer units (they're coarser/more searchable), else topics
  const anchors = units.length > 0
    ? units.slice(0, 3)
    : topics.slice(0, 5);

  const anchorStr = anchors.join(', ');

  switch (docType) {
    case DOCTYPE.SYLLABUS:
      return subject
        ? `${subject} — ${anchorStr || topics.slice(0, 4).join(', ')}`
        : anchorStr || topics.slice(0, 5).join(', ');

    case DOCTYPE.LECTURE:
      return subject
        ? `${subject} — explanation examples and concepts`
        : `${anchorStr} — explanation and examples`;

    case DOCTYPE.QUESTION: {
      // For question papers, extract topics from questions
      const qTopics = extractTopicsFromQuestions(questions, topics);
      const qStr = qTopics.slice(0, 4).join(', ');
      return subject
        ? `${subject} exam preparation — solved problems and practice: ${qStr}`
        : `${qStr} — solved problems practice questions exam preparation`;
    }

    case DOCTYPE.RESEARCH:
      return subject
        ? `${subject} — understanding the concepts`
        : `${anchorStr} — research concepts overview`;

    case DOCTYPE.STUDY:
    default:
      return subject
        ? `${subject} — ${anchorStr || topics.slice(0, 4).join(', ')}`
        : anchorStr || topics.slice(0, 5).join(', ');
  }
}

/**
 * For question papers: derive the most-tested topics from the question list
 * by identifying repeated keywords.
 */
function extractTopicsFromQuestions(questions, fallbackTopics) {
  if (questions.length === 0) return fallbackTopics.slice(0, 5);

  // Count keyword frequency in questions
  const STOP = new Set([
    'the', 'a', 'an', 'and', 'or', 'of', 'in', 'on', 'with', 'for', 'to', 'is', 'are',
    'define', 'explain', 'derive', 'find', 'calculate', 'prove', 'draw', 'write',
    'solve', 'describe', 'discuss', 'compare', 'state', 'what', 'how', 'why',
  ]);

  const freq = {};
  questions.forEach(q => {
    q.toLowerCase()
     .replace(/[^a-z0-9'\s-]/g, ' ')
     .split(/\s+/)
     .filter(w => w.length > 3 && !STOP.has(w))
     .forEach(w => { freq[w] = (freq[w] || 0) + 1; });
  });

  const topWords = Object.entries(freq)
    .filter(([, c]) => c >= 2)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([w]) => w);

  return topWords.length >= 2 ? topWords : fallbackTopics.slice(0, 5);
}

// ── Research hints ─────────────────────────────────────────────────────────────

function buildResearchHints(docType, structure) {
  switch (docType) {
    case DOCTYPE.SYLLABUS:
      return {
        practiceSignals:   ['exam'],
        preferredGoalType: 'exam-prep',
        docTypeLabel: DOCTYPE_LABEL[DOCTYPE.SYLLABUS],
      };
    case DOCTYPE.LECTURE:
      return {
        practiceSignals:   ['notes'],
        preferredGoalType: 'basics',
        docTypeLabel: DOCTYPE_LABEL[DOCTYPE.LECTURE],
      };
    case DOCTYPE.QUESTION:
      return {
        practiceSignals:   ['exam', 'numericals'],
        preferredGoalType: 'exam-prep',
        docTypeLabel: DOCTYPE_LABEL[DOCTYPE.QUESTION],
      };
    case DOCTYPE.RESEARCH:
      return {
        practiceSignals:   [],
        preferredGoalType: 'basics',
        docTypeLabel: DOCTYPE_LABEL[DOCTYPE.RESEARCH],
      };
    case DOCTYPE.STUDY:
    default:
      return {
        practiceSignals:   [],
        preferredGoalType: 'basics',
        docTypeLabel: DOCTYPE_LABEL[DOCTYPE.STUDY],
      };
  }
}

// ── Human-readable classification reason ──────────────────────────────────────

function describeClassification(type, structure) {
  const { units, topics, questions, subject } = structure;
  const uCount = units.length;
  const tCount = topics.length;
  const qCount = questions.length;

  switch (type) {
    case DOCTYPE.SYLLABUS:
      return `Found ${uCount > 0 ? uCount + ' units/modules and ' : ''}${tCount} study topics` +
        (subject ? ` for "${subject}"` : '') + '. Contains course structure and learning objectives.';
    case DOCTYPE.LECTURE:
      return `Found lecture content with ${tCount} topic references` +
        (subject ? ` on "${subject}"` : '') + '. Contains definitions, examples and explanations.';
    case DOCTYPE.QUESTION:
      return `Found ${qCount > 0 ? qCount + ' questions' : 'exam paper structure'}` +
        (subject ? ` from "${subject}"` : '') + '. Contains marks allocation and exam-style questions.';
    case DOCTYPE.RESEARCH:
      return `Found academic research structure` +
        (subject ? ` on "${subject}"` : '') + '. Contains abstract, methodology or references section.';
    case DOCTYPE.STUDY:
      return `Found ${tCount} study topics` +
        (subject ? ` in "${subject}"` : '') + '. Contains academic chapter or exercise structure.';
    default:
      return 'Academic document detected.';
  }
}

// ── Invalid result helper ──────────────────────────────────────────────────────

function invalidResult(reason, rawText = '', pageCount = 0) {
  return {
    isAcademic:    false,
    documentType:  DOCTYPE.INVALID,
    confidence:    0,
    reason,
    subject:       '',
    units:         [],
    topics:        [],
    questions:     [],
    composedTopic: '',
    researchHints: {
      practiceSignals: [],
      preferredGoalType: 'exam-prep',
      docTypeLabel: DOCTYPE_LABEL[DOCTYPE.INVALID],
    },
    rawText,
    pageCount,
    lowConfidence: false,
    docTypeLabel:  DOCTYPE_LABEL[DOCTYPE.INVALID],
  };
}

// ── Exports ────────────────────────────────────────────────────────────────────

module.exports = { analyzeDocument, DOCTYPE, DOCTYPE_LABEL, LOW_CONFIDENCE_THRESHOLD };
